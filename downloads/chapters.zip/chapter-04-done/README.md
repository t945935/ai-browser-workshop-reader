# 第 4 章完成版

在第 3 章本機按鈕視窗下方加入隔離的 WebContentsView。正常啟動載入固定的 https://example.com，尚未加入網址列或導覽按鈕。

本目錄執行 npm.cmd ci、npm.cmd start。npm.cmd run smoke 使用本機 HTTP 頁面，核對載入、縮放、外部頁面沒有 preload 能力及關閉釋放資源；它不證明外部網站連線成功。
