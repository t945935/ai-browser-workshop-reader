const { app, BrowserWindow, WebContentsView, ipcMain, session } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');
const smoke = process.argv.includes('--smoke-test');
if (smoke) app.setPath('userData', require('node:fs').mkdtempSync(path.join(require('node:os').tmpdir(),'chapter04-result-')));
const UI_HEIGHT = 112;
const uiUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
let window, page;
let message = '準備載入固定網頁。';
function state() { return { message, title: page.webContents.getTitle(), loading: page.webContents.isLoading() }; }
function publish() {
  if (window && !window.isDestroyed() && !page.webContents.isDestroyed()) window.webContents.send('browser:state', state());
}
function resize() {
  const [width, height] = window.getContentSize();
  page.setBounds({ x: 0, y: UI_HEIGHT, width, height: Math.max(0, height - UI_HEIGHT) });
}
ipcMain.handle('browser:command', (event, command) => {
  if (!window || event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame || event.senderFrame.url !== uiUrl) throw new Error('不允許的操作來源。');
  if (command === 'ping') return { message: '主程序已收到操作。' };
  if (command === 'state') return state();
  throw new Error('不支援的操作。');
});
async function runSmoke() {
  const server = require('node:http').createServer((_request, response) => { response.setHeader('Content-Type','text/html; charset=utf-8'); response.end('<!doctype html><html lang="zh-TW"><meta charset="utf-8"><title>Chapter 04 page</title><h1>第一個測試網頁</h1><p>這是本機 HTTP 頁面，已載入獨立網頁檢視。</p></html>'); });
  try {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    await page.webContents.loadURL(`http://127.0.0.1:${server.address().port}`);
    assert.equal(page.webContents.getTitle(), 'Chapter 04 page');
    assert.equal(await page.webContents.executeJavaScript('typeof require'), 'undefined');
    assert.equal(await page.webContents.executeJavaScript('typeof window.browser'), 'undefined');
    assert.equal(await window.webContents.executeJavaScript("window.browser.command('ping').then(value=>value.message)"), '主程序已收到操作。');
    window.setContentSize(760, 520); resize();
    assert.deepEqual(page.getBounds(), { x: 0, y: 112, width: 760, height: 408 });
    window.showInactive();
    await require('../tools/capture-result').captureResult(window.webContents,'fixed-page-toolbar',{x:0,y:0,width:760,height:112});
    await require('../tools/capture-result').captureResult(page.webContents,'fixed-page-content');
    const destroyed = new Promise(resolve => page.webContents.once('destroyed', resolve));
    window.close(); await destroyed;
    console.log('CHAPTER 04 PASS: fixed page, resize bounds, isolated page, resource closed');
    server.close(); app.quit();
  } catch (error) { server.close(); console.error('CHAPTER 04 FAIL:', error.message); app.exit(1); }
}
function createWindow() {
  window = new BrowserWindow({ width: 1100, height: 760, minWidth: 640, minHeight: 360, show: !smoke,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), nodeIntegration: false, contextIsolation: true, sandbox: true }
  });
  window.setMenuBarVisibility(false);
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  page = new WebContentsView({ webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, partition: 'chapter-04-page' } });
  window.contentView.addChildView(page); resize();
  window.on('resize', resize);
  page.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  for (const name of ['will-navigate','will-redirect']) page.webContents.on(name, (event, url) => {
    try { if (!['http:','https:'].includes(new URL(url).protocol)) event.preventDefault(); }
    catch { event.preventDefault(); }
  });
  page.webContents.on('did-start-loading', () => { message = ''; publish(); });
  page.webContents.on('did-stop-loading', publish);
  page.webContents.on('page-title-updated', publish);
  page.webContents.on('did-fail-load', (_event, code, description, _url, isMainFrame) => {
    if (isMainFrame && code !== -3) { message = `無法載入網頁：${description}`; publish(); }
  });
  window.on('closed', () => { if (!page.webContents.isDestroyed()) page.webContents.close(); });
  window.webContents.once('did-finish-load', () => {
    if (smoke) runSmoke();
    else page.webContents.loadURL('https://example.com').catch(error => {
      if (error.code !== 'ERR_ABORTED') { message = `無法載入網頁：${error.code || '請檢查網路'}`; publish(); }
    });
  });
  window.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => {
  const browserSession = session.fromPartition('chapter-04-page');
  browserSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  browserSession.setPermissionCheckHandler(() => false);
  browserSession.on('will-download', event => event.preventDefault());
  createWindow();
});
app.on('window-all-closed', () => { if (!smoke) app.quit(); });
if (smoke) setTimeout(() => { console.error('CHAPTER 04 FAIL: timeout'); app.exit(1); }, 15000).unref();
