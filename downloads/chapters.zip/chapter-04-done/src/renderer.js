const status = document.querySelector('#status');
document.querySelector('#inspect-button').addEventListener('click', async () => {
  try { status.textContent = (await window.browser.command('ping')).message; }
  catch { status.textContent = '操作失敗，請核對 preload。'; }
});
function render(state) {
  document.querySelector('#page-status').textContent = state.message || (state.loading ? '正在載入…' : state.title || '就緒');
}
window.browser.onState(render);
window.browser.command('state').then(render).catch(() => { status.textContent = '無法取得頁面狀態。'; });
