const { randomUUID } = require('node:crypto');
const { normalizeUrl } = require('./url');
class AiWorkflow {
  constructor(client) { this.client = client; this.pagePreview = null; }
  previewPage(value) {
    const url = normalizeUrl(value?.url);
    if (!url || typeof value.text !== 'string' || !value.text.trim()) throw new Error('此頁沒有可摘要文字。');
    const token = randomUUID(); const text = value.text.trim().slice(0, 12000);
    this.pagePreview = { token, text, url, title: String(value.title || '').slice(0, 200), created: Date.now() };
    return { ...this.pagePreview, truncated: value.text.trim().length > text.length };
  }
  async summarize(token) {
    if (this.client.busy) throw new Error('AI 請求進行中，請等待或取消。');
    const preview = this.pagePreview;
    if (!preview || preview.token !== token || Date.now() - preview.created > 600000) throw new Error('摘要預覽已失效，請重新擷取。');
    this.pagePreview = null;
    const text = await this.client.request(preview.text);
    return { text, sourceUrl: preview.url, sourceTitle: preview.title };
  }
  discard() { this.pagePreview = null; }
}
module.exports = { AiWorkflow };
