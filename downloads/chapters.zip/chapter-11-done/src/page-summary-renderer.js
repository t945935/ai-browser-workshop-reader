(() => {
  const find=id=>document.querySelector(`#${id}`);
  let token,sourceUrl,waiting=false;
  const status=find('page-summary-status');
  async function invoke(command,input) {
    const result=await window.browser.command(command,input);
    if(result.error) throw new Error(result.error);
    return result;
  }
  function busy(value) {
    waiting=value;
    for(const id of ['page-preview','page-confirm','page-discard']) find(id).disabled=value;
    find('page-cancel-request').disabled=!value;
  }
  find('page-preview').addEventListener('click',async()=>{
    if(waiting) return;
    token=undefined; find('page-preview-box').hidden=true;
    try {
      const {preview}=await invoke('ai-page-preview'); token=preview.token;
      find('page-preview-source').textContent=`來源：${preview.title} ${preview.url}`;
      find('page-preview-text').value=preview.text;
      find('page-truncated').textContent=preview.truncated?'超過上限，只預覽及送出前 12000 字元。':'內容未截取。';
      find('page-preview-box').hidden=false; status.textContent='尚未送出，請檢查預覽。';
    } catch(error) {status.textContent=error.message;}
  });
  find('page-discard').addEventListener('click',async()=>{
    if(waiting) return;
    try {await invoke('ai-discard');token=undefined;find('page-preview-box').hidden=true;status.textContent='預覽已取消，未發出請求。';}
    catch(error) {status.textContent=error.message;}
  });
  find('page-confirm').addEventListener('click',async()=>{
    if(waiting || !token) return;
    const selected=token;token=undefined;busy(true);find('page-preview-box').hidden=true;
    status.textContent='等待摘要…';find('page-summary-output').textContent='';find('page-summary-source').textContent='';find('page-open-source').hidden=true;
    try {
      const {summary}=await invoke('ai-summary',selected);
      sourceUrl=summary.sourceUrl;find('page-summary-output').textContent=summary.text;
      find('page-summary-source').textContent=`來源：${summary.sourceTitle} ${sourceUrl}`;
      find('page-open-source').hidden=false;status.textContent='摘要完成，請回到來源核對。';
    } catch(error) {status.textContent=error.message;}
    finally {busy(false);}
  });
  find('page-cancel-request').addEventListener('click',async()=>{
    try {await invoke('ai-cancel');} catch(error) {status.textContent=error.message;}
  });
  find('page-open-source').addEventListener('click',async()=>{
    try {await invoke('navigate',sourceUrl);} catch(error) {status.textContent=error.message;}
  });
})();
