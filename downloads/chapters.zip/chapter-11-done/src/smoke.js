const assert=require('node:assert/strict');
const http=require('node:http');
const {captureResult}=require('../tools/capture-result');
async function run({app,window,active,newTab,switchTab,aiClient}) {
  const timer=setTimeout(()=>app.exit(1),20000);
  const server=http.createServer((request,response)=>{
    response.setHeader('Content-Type','text/html; charset=utf-8');
    const text=request.url==='/empty'?'':request.url==='/long'?'字'.repeat(13000):'這是自寫的來源文字：工作瀏覽器提供資料整理與設定保存。';
    response.end(`<html lang="zh-TW"><meta charset="utf-8"><title>摘要練習來源</title><body>${text}</body></html>`);
  });
  const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text) {
    await js(`new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('摘要介面逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#page-summary-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timeout);clearInterval(poll);resolve();}},20);})`);
  }
  async function capture(name) {
    await js("document.querySelector('#page-summary-panel').scrollIntoView();new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
    const box=await js("(()=>{const b=document.querySelector('#page-summary-panel').getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()");
    assert.ok(box.y>=184 && box.y+box.height<=window.getContentSize()[1]);
    await captureResult(window.webContents,name,{x:0,y:box.y,width:300,height:box.height});
  }
  try {
    window.setContentSize(1200,1200);
    window.showInactive();
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const base=`http://127.0.0.1:${server.address().port}`;
    const first=active();await first.view.webContents.loadURL(base+'/source');
    await js("window.browser.command('ai-config',{model:'offline-model',key:'offline-fixture-not-a-real-key'})");
    let calls=0;
    aiClient.fetcher=async(_url,options)=>{
      calls++;assert.match(JSON.parse(options.body).input[0].content[0].text,/自寫的來源文字/);
      return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'離線測試摘要：來源介紹資料整理與設定保存。'}]}]})};
    };
    await js("document.querySelector('#page-preview').click()");await waitFor('尚未送出');
    assert.equal(calls,0);assert.match(await js("document.querySelector('#page-preview-text').value"),/自寫的來源文字/);
    assert.equal(await js("document.querySelector('#page-preview-text').readOnly"),true);
    await capture('page-preview');
    const second=newTab();await second.view.webContents.loadURL(base+'/other');
    await js("document.querySelector('#page-confirm').click()");await waitFor('摘要完成');
    assert.equal(calls,1);assert.match(await js("document.querySelector('#page-summary-source').textContent"),new RegExp('/source'));
    await capture('page-summary');
    switchTab(first.id);
    await js("document.querySelector('#page-preview').click()");await waitFor('尚未送出');
    await js("document.querySelector('#page-discard').click()");await waitFor('預覽已取消');assert.equal(calls,1);
    await first.view.webContents.loadURL(base+'/empty');
    await js("document.querySelector('#page-preview').click()");await waitFor('沒有可摘要');assert.equal(calls,1);
    await first.view.webContents.loadURL(base+'/long');
    await js("document.querySelector('#page-preview').click()");await waitFor('尚未送出');
    assert.equal(await js("document.querySelector('#page-preview-text').value.length"),12000);
    assert.match(await js("document.querySelector('#page-truncated').textContent"),/超過上限/);
    const contents=first.view.webContents,original=contents.executeJavaScript;
    contents.executeJavaScript=async function(script){const text=await original.call(this,script);await this.loadURL(base+'/changed');return text;};
    try {const changed=await js("window.browser.command('ai-page-preview')");assert.match(changed.error,/頁面已變更/);}
    finally {contents.executeJavaScript=original;}
    console.log('CHAPTER 11 PASS: actual page extraction, preview before request, readonly text, source preserved across tabs, discard, empty page, truncation, changed URL; offline API');
  } finally {aiClient.cancel();server.close();clearTimeout(timer);window.close();}
}
module.exports={run};
