const {test}=require('node:test');
const assert=require('node:assert/strict');
const {AiWorkflow}=require('../src/ai-workflow');
test('摘要預覽不送出，確認保留來源並只使用一次 token',async()=>{
  let calls=0;const client={busy:false,request:async text=>{calls++;assert.equal(text,'來源文字');return '離線摘要';}};
  const workflow=new AiWorkflow(client);
  const preview=workflow.previewPage({url:'https://example.com/a',title:'來源',text:'來源文字'});
  assert.equal(calls,0);
  const result=await workflow.summarize(preview.token);
  assert.deepEqual(result,{text:'離線摘要',sourceUrl:'https://example.com/a',sourceTitle:'來源'});
  await assert.rejects(workflow.summarize(preview.token),/失效/);assert.equal(calls,1);
});
test('空內容拒絕，長文字截取，取消與過期預覽失效',async()=>{
  let calls=0;const workflow=new AiWorkflow({busy:false,request:async()=>{calls++;return '摘要';}});
  assert.throws(()=>workflow.previewPage({url:'https://example.com',text:'   '}),/沒有可摘要/);
  const preview=workflow.previewPage({url:'https://example.com',text:'字'.repeat(12001)});
  assert.equal(preview.text.length,12000);assert.equal(preview.truncated,true);
  workflow.discard();await assert.rejects(workflow.summarize(preview.token),/失效/);
  const old=workflow.previewPage({url:'https://example.com',text:'資料'});workflow.pagePreview.created=Date.now()-600001;
  await assert.rejects(workflow.summarize(old.token),/失效/);assert.equal(calls,0);
});
