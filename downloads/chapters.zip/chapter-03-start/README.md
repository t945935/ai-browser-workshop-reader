# 第 3 章起始版

沿用第 2 章本機視窗。先在自己的副本執行 npm.cmd ci、npm.cmd start，再依第 3 章拆分 main、preload 與 renderer，加入本機按鈕通訊。完成版在相鄰 chapter-03-done。
