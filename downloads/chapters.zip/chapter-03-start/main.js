const { app, BrowserWindow } = require('electron');
const smoke = process.argv.includes('--smoke-test');
app.whenReady().then(() => {
  const window = new BrowserWindow({
    width: 900, height: 600, show: !smoke,
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true }
  });
  window.loadFile('index.html');
  if (smoke) {
    const timer = setTimeout(() => { console.error('FIRST WINDOW FAIL: timeout'); app.exit(1); }, 10000);
    window.webContents.once('did-finish-load', async () => {
      try {
        if (await window.webContents.executeJavaScript("document.querySelector('h1').textContent") !== '程式已啟動') throw new Error('頁面文字不正確');
        console.log('FIRST WINDOW PASS'); clearTimeout(timer); window.close();
      } catch (error) { console.error(error); app.exit(1); }
    });
  }
});
app.on('window-all-closed', () => app.quit());
