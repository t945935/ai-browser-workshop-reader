const fs = require('node:fs');
const path = require('node:path');
const { normalizeUrl } = require('./url');
function defaults() { return { version: 1, favorites: [], panelVisible: true }; }
function validateSettings(value) {
  if (!value || value.version !== 1 || !Array.isArray(value.favorites) || typeof value.panelVisible !== 'boolean') throw new Error('設定格式不正確。');
  if (value.favorites.length > 100) throw new Error('常用網站最多 100 筆。');
  const favorites = value.favorites.map(item => {
    if (!item || typeof item.title !== 'string' || !item.title.trim() || item.title.length > 200) throw new Error('網站名稱不正確。');
    const url = normalizeUrl(item.url);
    if (!url) throw new Error('網站網址不可空白。');
    return { title: item.title.trim(), url };
  });
  if (new Set(favorites.map(item => item.url)).size !== favorites.length) throw new Error('網站網址重複。');
  return { version: 1, favorites, panelVisible: value.panelVisible };
}
class SettingsStore {
  constructor(directory) {
    fs.mkdirSync(directory, { recursive: true });
    this.file = path.join(directory, 'settings.json'); this.value = defaults(); this.error = '';
    try { this.value = validateSettings(JSON.parse(fs.readFileSync(this.file, 'utf8'))); }
    catch (error) { if (error.code !== 'ENOENT') this.error = '設定檔損壞，已暫用預設值；請按回復設定保留原檔並重新建立。'; }
  }
  save(value) {
    if (this.error) throw new Error(this.error);
    const next = validateSettings(value);
    fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(next, null, 2), 'utf8');
    fs.renameSync(`${this.file}.tmp`, this.file); this.value = next;
  }
  reset() {
    if (fs.existsSync(this.file)) fs.copyFileSync(this.file, `${this.file}.backup-${Date.now()}`);
    this.error = ''; this.save(defaults());
  }
}
module.exports = { SettingsStore, validateSettings };
