const { randomUUID } = require('node:crypto');
function validateBook(value) {
  if (!value || typeof value.title !== 'string' || !value.title.trim()) throw new Error('書名不可空白。');
  for (const key of ['title','author','description']) if (value[key] !== undefined && (typeof value[key] !== 'string' || value[key].length > 20000)) throw new Error(`${key} 格式不正確。`);
  if (!Array.isArray(value.keywords) || value.keywords.length > 100 || value.keywords.some(word => typeof word !== 'string' || word.length > 200)) throw new Error('關鍵字格式不正確。');
  return { title: value.title.trim(), author: value.author || '', description: value.description || '', keywords: value.keywords.map(word=>word.trim()).filter(Boolean) };
}
class BookStore {
  constructor() { this.rows = new Map(); }
  list(query = '') {
    if (typeof query !== 'string' || query.length > 200) throw new Error('搜尋文字過長。');
    return [...this.rows.values()].filter(book => ['title','author','description'].some(key=>book[key].includes(query))).map(book=>structuredClone(book));
  }
  get(id) { const book = this.rows.get(id); return book ? structuredClone(book) : undefined; }
  save(value) {
    const checked = validateBook(value);
    if (value.id !== undefined && (typeof value.id !== 'string' || !this.rows.has(value.id))) throw new Error('書籍已不存在，請重新選擇。');
    const id = value.id || randomUUID(); const previous = this.rows.get(id); const now = new Date().toISOString();
    this.rows.set(id, { ...checked, id, createdAt: previous?.createdAt || now, updatedAt: now });
    return this.get(id);
  }
  delete(id) { if (typeof id !== 'string') throw new Error('識別碼不正確。'); this.rows.delete(id); }
  close() { this.rows.clear(); }
}
module.exports = { BookStore, validateBook };
