const { app, BrowserWindow, WebContentsView, ipcMain, session } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { randomUUID } = require('node:crypto');
const { normalizeUrl } = require('./url');
const { SettingsStore } = require('./settings');
const { BookStore } = require('./books');
const { dialog } = require('electron');
const UI_HEIGHT = 184;
const PANEL_WIDTH = 300;
const smoke = process.argv.includes('--smoke-test');
const uiUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
if (smoke) app.setPath('userData', path.join(app.getPath('temp'), `ai-browser-smoke-${randomUUID()}`));
let window, settings, books, activeId;
const tabs = new Map();
let globalMessage = '';
function active() { return tabs.get(activeId); }
function state() {
  const tab = active(); const contents = tab?.view.webContents;
  return {
    url: contents?.getURL() || '', title: contents?.getTitle() || '', loading: contents?.isLoading() || false,
    message: globalMessage || settings.error || tab?.message || '',
    canGoBack: contents?.navigationHistory.canGoBack() || false, canGoForward: contents?.navigationHistory.canGoForward() || false,
    activeId, tabs: [...tabs.values()].map(item => ({ id: item.id, title: item.view.webContents.getTitle() || '新分頁' })),
    settings: settings.value, settingsError: Boolean(settings.error), dataPath: app.getPath('userData')
  };
}
function publish() { if (window && !window.isDestroyed()) window.webContents.send('browser:state', state()); }
function resize() {
  if (!window || window.isDestroyed()) return;
  const [width, height] = window.getContentSize(); const x = settings.value.panelVisible ? PANEL_WIDTH : 0;
  for (const tab of tabs.values()) {
    tab.view.setBounds({ x, y: UI_HEIGHT, width: Math.max(0, width - x), height: Math.max(0, height - UI_HEIGHT) });
    tab.view.setVisible(tab.id === activeId);
  }
}
function switchTab(id) {
  if (!tabs.has(id)) throw new Error('找不到分頁。');
  activeId = id; globalMessage = ''; resize(); publish();
}
function newTab() {
  if (tabs.size >= 20) throw new Error('最多開啟 20 個分頁。');
  const tab = { id: randomUUID(), message: '輸入網址開始瀏覽。', view: new WebContentsView({ webPreferences: {
    contextIsolation: true, nodeIntegration: false, sandbox: true, partition: 'browser-prototype'
  } }) };
  tabs.set(tab.id, tab); window.contentView.addChildView(tab.view);
  const contents = tab.view.webContents;
  contents.setWindowOpenHandler(() => ({ action: 'deny' }));
  for (const name of ['will-navigate', 'will-redirect']) contents.on(name, (event, url) => {
    try { normalizeUrl(url); } catch (error) { event.preventDefault(); tab.message = error.message; publish(); }
  });
  contents.on('did-start-loading', () => { tab.message = ''; publish(); });
  for (const name of ['did-stop-loading', 'did-navigate', 'did-navigate-in-page', 'page-title-updated']) contents.on(name, publish);
  contents.on('did-fail-load', (_event, code, description, _url, isMainFrame) => {
    if (isMainFrame && code !== -3) { tab.message = `無法載入網頁：${description}`; publish(); }
  });
  contents.on('render-process-gone', () => { tab.message = '網頁程序已停止，請重新整理。'; publish(); });
  switchTab(tab.id); return tab;
}
function closeTab(id) {
  const tab = tabs.get(id); if (!tab) throw new Error('找不到分頁。');
  window.contentView.removeChildView(tab.view); tabs.delete(id); tab.view.webContents.close();
  if (!tabs.size) newTab(); else if (activeId === id) switchTab([...tabs.keys()].at(-1));
  publish();
}
function navigate(input) {
  const target = normalizeUrl(input); if (!target) return;
  const tab = active(); tab.message = '';
  tab.view.webContents.loadURL(target).catch(error => {
    if (error.code !== 'ERR_ABORTED' && tabs.has(tab.id)) { tab.message = `無法載入網頁：${error.code || '請檢查網路與網址'}`; publish(); }
  });
}
function trusted(event) {
  return window && event.sender === window.webContents && event.senderFrame === window.webContents.mainFrame && event.senderFrame.url === uiUrl;
}
ipcMain.handle('browser:command', async (event, command, input) => {
  if (!trusted(event)) throw new Error('不允許的操作來源。');
  try {
    globalMessage = ''; const contents = active().view.webContents; const history = contents.navigationHistory;
    switch (command) {
      case 'state': break;
      case 'navigate': navigate(input); break;
      case 'back': if (history.canGoBack()) history.goBack(); break;
      case 'forward': if (history.canGoForward()) history.goForward(); break;
      case 'reload': if (contents.getURL()) contents.reload(); break;
      case 'new-tab': newTab(); break;
      case 'switch-tab': switchTab(input); break;
      case 'close-tab': closeTab(input); break;
      case 'add-favorite': {
        const url = normalizeUrl(contents.getURL()); if (!url) throw new Error('請先開啟網站。');
        if (settings.value.favorites.some(item => item.url === url)) throw new Error('此網站已在常用網站清單。');
        settings.save({ ...settings.value, favorites: [...settings.value.favorites, { title: contents.getTitle() || url, url }] }); break;
      }
      case 'remove-favorite': settings.save({ ...settings.value, favorites: settings.value.favorites.filter(item => item.url !== input) }); break;
      case 'toggle-panel': settings.save({ ...settings.value, panelVisible: !settings.value.panelVisible }); resize(); break;
      case 'reset-settings': settings.reset(); resize(); break;
      case 'books-list': return { books: books.list(input || '') };
      case 'books-save': return { book: books.save(input) };
      case 'books-delete': {
        if (typeof input !== 'string') throw new Error('識別碼不正確。');
        const result = await dialog.showMessageBox(window, { type:'question', buttons:['取消','刪除'], defaultId:0, cancelId:0, message:'確定刪除這筆書籍？' });
        if (result.response === 1) books.delete(input);
        return { deleted:result.response === 1 };
      }
      default: throw new Error('不支援的操作。');
    }
  } catch (error) { globalMessage = error.message; if (typeof command === 'string' && command.startsWith('books-')) return { error:error.message }; }
  publish(); return state();
});
function createWindow() {
  settings = new SettingsStore(app.getPath('userData')); books = new BookStore();
  window = new BrowserWindow({ width: 1200, height: 800, minWidth: 700, minHeight: 400, title: 'My AI Browser', backgroundColor: '#f3f6fa', show: !smoke,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  window.setMenuBarVisibility(false);
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  newTab(); window.on('resize', resize);
  window.on('closed', () => {
    const oldTabs = [...tabs.values()]; tabs.clear(); books.close(); window = null;
    for (const tab of oldTabs) if (!tab.view.webContents.isDestroyed()) tab.view.webContents.close();
  });
  window.loadFile(path.join(__dirname, 'index.html'));
  if (smoke) window.webContents.once('did-finish-load', () => require('./smoke').run({ app, window, tabs, active, state, newTab, switchTab, closeTab, settings, resize }).catch(error => {
    console.error('SMOKE FAIL:', error); app.exit(1);
  }));
}
app.whenReady().then(() => {
  const browserSession = session.fromPartition('browser-prototype');
  browserSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  browserSession.setPermissionCheckHandler(() => false);
  browserSession.on('will-download', event => event.preventDefault());
  createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
