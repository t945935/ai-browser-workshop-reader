const assert = require('node:assert/strict');
const { dialog } = require('electron');
const { BookStore } = require('./books');
const { SettingsStore } = require('./settings');
const fs = require('node:fs');
const path = require('node:path');
async function run({ app, window }) {
  const timer = setTimeout(()=>app.exit(1),15000);
  const originalDialog = dialog.showMessageBox;
  try {
    const book = await window.webContents.executeJavaScript("window.browser.command('books-save',{title:'面板驗收',author:'範例作者',description:'第一行\\n第二行',keywords:['含,逗號']})");
    assert.equal(book.book.title,'面板驗收');
    await window.webContents.executeJavaScript(`selectBook(${JSON.stringify(book.book)});document.querySelector('#book-description').value='更新簡介';document.querySelector('#book-form').requestSubmit();new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('儲存介面逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#book-status').textContent==='已儲存。'){clearInterval(poll);clearTimeout(timeout);resolve();}},20);})`);
    const list = await window.webContents.executeJavaScript("window.browser.command('books-list','面板')");
    assert.equal(list.books.length,1); assert.equal(list.books[0].id,book.book.id); assert.equal(list.books[0].description,'更新簡介');
    window.setContentSize(1200,1000);
    await window.webContents.executeJavaScript("document.querySelector('#panel').scrollTop=50;new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
    const imageDirectory = path.join(app.getAppPath(),'assets/images');
    fs.mkdirSync(imageDirectory,{recursive:true});
    fs.writeFileSync(path.join(imageDirectory,'memory-book-panel.png'),(await window.webContents.capturePage({x:0,y:184,width:300,height:690})).toPNG());
    const invalid = await window.webContents.executeJavaScript("window.browser.command('books-save',{title:'',keywords:[]})");
    assert.match(invalid.error,/書名/);
    dialog.showMessageBox = async()=>({response:0});
    assert.equal((await window.webContents.executeJavaScript(`window.browser.command('books-delete',${JSON.stringify(book.book.id)})`)).deleted,false);
    assert.equal((await window.webContents.executeJavaScript("window.browser.command('books-list')")).books.length,1);
    dialog.showMessageBox = async()=>({response:1});
    assert.equal((await window.webContents.executeJavaScript(`window.browser.command('books-delete',${JSON.stringify(book.book.id)})`)).deleted,true);
    assert.equal((await window.webContents.executeJavaScript("window.browser.command('books-list')")).books.length,0);
    assert.equal(new BookStore().list().length,0);
    const settings = await window.webContents.executeJavaScript("window.browser.command('toggle-panel')");
    const reopened = new SettingsStore(app.getPath('userData'));
    if (reopened.file) {
      assert.equal(reopened.value.panelVisible,settings.settings.panelVisible);
      assert.ok(fs.existsSync(reopened.file));
      console.log('CHAPTER 08 PASS: persistent JSON settings, memory books, save/update/delete confirmation (native dialog stubbed)');
    } else {
      assert.equal(reopened.value.panelVisible,true);
      console.log('CHAPTER 07 PASS: memory books, save/update/search, invalid title, delete confirmation (native dialog stubbed)');
    }
  } finally { dialog.showMessageBox = originalDialog; clearTimeout(timer); window.close(); }
}
module.exports = { run };
