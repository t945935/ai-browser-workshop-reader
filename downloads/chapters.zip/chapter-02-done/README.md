# 第 2 章完成版

包含 main.js 與 index.html，可開啟第一個本機視窗。在自己的練習副本執行 npm.cmd ci、npm.cmd start。Electron 固定 44.5.0。

自動驗收可執行 npm.cmd exec -- electron . --smoke-test；本章沒有網址列或外部網頁。起始版尚無入口程式，請依正文建立後再執行。
