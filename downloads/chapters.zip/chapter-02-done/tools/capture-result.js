// 擷取實際渲染內容；UI 與 WebContentsView 分別存圖，不合成示意畫面。
const fs = require('node:fs');
const path = require('node:path');
const { app } = require('electron');
async function captureResult(contents, name, rectangle) {
  // 隱藏的 WebContentsView 可能暫停 requestAnimationFrame，不能以它作為等待條件。
  await contents.executeJavaScript("document.fonts.ready.then(()=>new Promise(resolve=>setTimeout(resolve,150)))");
  const image = await contents.capturePage(rectangle);
  if (image.isEmpty()) throw new Error('執行結果截圖為空。');
  const directory = path.join(app.getAppPath(),'assets/results');
  fs.mkdirSync(directory,{recursive:true});
  fs.writeFileSync(path.join(directory,`${name}.png`),image.toPNG());
}
module.exports = { captureResult };
