const {test}=require('node:test');const assert=require('node:assert/strict');
const {FormWorkflow}=require('../src/form-workflow');
test('填表取消、分頁與資料變更、過期及 token 重用不執行寫入',async()=>{
  const original={id:'book',title:'範例',author:'作者',description:'兩行\n內容',keywords:['含,逗號']};let book=original,calls=0;
  const url='http://127.0.0.1:1234/';
  const workflow=new FormWorkflow({allows:value=>value===url},{get:()=>book});
  const contents={id:1,getURL:()=>url,isDestroyed:()=>false,executeJavaScript:async()=>{calls++;return {fields:[],submitted:'0'};}};
  let preview=await workflow.preview(contents,'book');assert.equal(preview.fields[3].value,'["含,逗號"]');assert.equal(calls,1);
  workflow.discard();await assert.rejects(workflow.fill(contents,preview.token),/失效/);assert.equal(calls,1);
  preview=await workflow.preview(contents,'book');await assert.rejects(workflow.fill({...contents,id:2},preview.token),/失效/);
  book={...book,description:'已修改'};await assert.rejects(workflow.fill(contents,preview.token),/已變更/);
  preview=await workflow.preview(contents,'book');workflow.pending.created=Date.now()-600001;await assert.rejects(workflow.fill(contents,preview.token),/失效/);
  preview=await workflow.preview(contents,'book');await workflow.fill(contents,preview.token);const used=calls;
  await assert.rejects(workflow.fill(contents,preview.token),/失效/);assert.equal(calls,used);assert.equal(workflow.busy,false);
});
test('不允許來源或讀取中斷會停止，請求鎖會恢復',async()=>{
  const workflow=new FormWorkflow({allows:()=>false},{get:()=>({title:'書',keywords:[]})});
  await assert.rejects(workflow.preview({getURL:()=> 'https://example.com'},'id'),/僅允許/);assert.equal(workflow.busy,false);
  workflow.server.allows=()=>true;
  await assert.rejects(workflow.preview({getURL:()=> 'http://127.0.0.1/',executeJavaScript:async()=>{throw new Error('中斷');}},'id'),/操作中斷/);
  assert.equal(workflow.busy,false);
});
