(() => {
  const find=id=>document.querySelector(`#${id}`);let token,waiting=false;
  const status=find('form-status');
  async function invoke(command,input) {
    const result=await window.browser.command(command,input);if(result.error)throw new Error(result.error);return result;
  }
  function busy(value){waiting=value;for(const id of ['form-preview-button','form-confirm','form-discard'])find(id).disabled=value;}
  find('form-preview-button').addEventListener('click',async()=>{
    if(waiting)return;token=undefined;find('form-preview-box').hidden=true;find('form-result').textContent='';busy(true);status.textContent='讀取欄位…';
    try {
      const {preview}=await invoke('form-preview',selectedBookId);token=preview.token;
      find('form-target').textContent=`目標：${preview.url}`;find('form-values').textContent=JSON.stringify(preview.fields,null,2);
      find('form-preview-box').hidden=false;status.textContent='尚未填入，請核對對應與內容。';
    } catch(error){status.textContent=error.message;}
    finally {busy(false);}
  });
  find('form-discard').addEventListener('click',async()=>{
    if(waiting)return;
    try {await invoke('form-discard');token=undefined;find('form-preview-box').hidden=true;status.textContent='預覽已取消，欄位未變更。';}
    catch(error){status.textContent=error.message;}
  });
  find('form-confirm').addEventListener('click',async()=>{
    if(waiting || !token)return;const selected=token;token=undefined;find('form-preview-box').hidden=true;busy(true);status.textContent='填入並核對中…';
    try {
      const {result}=await invoke('form-fill',selected);find('form-result').textContent=JSON.stringify(result,null,2);
      status.textContent=result.submitted==='0'?'已填入並核對，尚未提交。':'已填入並核對；頁面曾有提交，請人工核對。';
    } catch(error){status.textContent=error.message;}
    finally {busy(false);}
  });
})();
