const {randomUUID}=require('node:crypto');
const {readFields}=require('./dom-reader');
// 固定函式在示範網頁執行，readFields 由固定程式碼一同注入。
function fillFields(expectedUrl,payload) {
  const before=readFields(expectedUrl);if(before.error)return before;
  const entries=before.fields.map(field=>{
    const element=document.getElementById(field.id);
    const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element),'value')?.set;
    return {field,element,setter};
  });
  if(entries.some(({element,setter})=>!setter || (element.tagName==='INPUT' && element.type!=='text')))return {error:'欄位型別不支援。'};
  for(const {field,element,setter} of entries) {
    if(location.href!==expectedUrl)return {error:'示範頁面已變更。'};
    setter.call(element,payload[field.id]);
    element.dispatchEvent(new Event('input',{bubbles:true}));
    element.dispatchEvent(new Event('change',{bubbles:true}));
  }
  const after=readFields(expectedUrl);if(after.error)return after;
  if(after.fields.some(field=>field.value!==payload[field.id]))return {error:'填入後欄位值不一致，請人工核對。'};
  return after;
}
class FormWorkflow {
  constructor(server,books){this.server=server;this.books=books;this.pending=null;this.busy=false;}
  async inspect(contents,payload=null) {
    const url=contents.getURL();if(!this.server.allows(url))throw new Error('自動填表僅允許本次啟動的本機示範網站。');
    let result;
    const script=`(()=>{const readFields=${readFields.toString()};return (${fillFields.toString()})(${JSON.stringify(url)},${JSON.stringify(payload)});})()`;
    try {result=await contents.executeJavaScript(payload ? script : `(${readFields.toString()})(${JSON.stringify(url)})`);}
    catch {throw new Error('頁面操作中斷，請重新開啟示範網站。');}
    if(contents.isDestroyed() || contents.getURL()!==url)throw new Error('示範頁面已變更。');
    if(result.error)throw new Error(result.error);
    return {...result,url};
  }
  async preview(contents,id) {
    if(this.busy)throw new Error('表單操作進行中，請稍候。');
    if(typeof id!=='string')throw new Error('請先選擇已儲存的書籍。');
    const book=this.books.get(id);if(!book)throw new Error('書籍已不存在。');
    this.busy=true;this.pending=null;
    try {
      const result=await this.inspect(contents);const token=randomUUID();
      const values={title:book.title,author:book.author,description:book.description,keywords:JSON.stringify(book.keywords)};
      this.pending={token,book,url:result.url,contentsId:contents.id,values,created:Date.now()};
      return {token,url:result.url,fields:Object.entries(values).map(([id,value])=>({id,value}))};
    } finally {this.busy=false;}
  }
  async fill(contents,token) {
    if(this.busy)throw new Error('表單操作進行中，請稍候。');
    const pending=this.pending;
    if(!pending || pending.token!==token || pending.contentsId!==contents.id || pending.url!==contents.getURL() || Date.now()-pending.created>600000)throw new Error('填表預覽已失效，請重新預覽。');
    if(JSON.stringify(this.books.get(pending.book.id))!==JSON.stringify(pending.book))throw new Error('書籍已變更，請重新預覽。');
    this.busy=true;this.pending=null;
    try {const result=await this.inspect(contents,pending.values);return {fields:result.fields,submitted:result.submitted};}
    finally {this.busy=false;}
  }
  discard(){this.pending=null;}
}
module.exports={FormWorkflow,fillFields};
