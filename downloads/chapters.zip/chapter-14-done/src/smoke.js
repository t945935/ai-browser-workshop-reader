const assert=require('node:assert/strict');const {captureResult}=require('../tools/capture-result');
async function run({app,window,active,newTab,switchTab,practice,books}) {
  const timer=setTimeout(()=>app.exit(1),20000);const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text){await js(`new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('填表介面逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#form-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timeout);clearInterval(poll);resolve();}},20);})`);}
  async function capture(name){
    await js("document.querySelector('#form-panel').scrollIntoView();new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
    const box=await js("(()=>{const b=document.querySelector('#form-panel').getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()");
    assert.ok(box.y>=184 && box.y+box.height<=window.getContentSize()[1]);
    await captureResult(window.webContents,name,{x:0,y:box.y,width:300,height:box.height});
  }
  try {
    window.setContentSize(1200,1200);window.showInactive();const first=active(),contents=first.view.webContents;
    const book=books.save({title:'填表 "引號" 練習',author:'範例作者',description:'第一行\n第二行：文字 <b>不是 HTML</b>',keywords:['含,逗號','表單']});
    await js(`selectBook(${JSON.stringify(book)})`);await contents.loadURL(practice.origin+'/');
    await js("document.querySelector('#form-preview-button').click()");await waitFor('尚未填入');
    assert.equal(await contents.executeJavaScript("document.querySelector('#title').value"),'');await capture('form-preview');
    await js("document.querySelector('#form-discard').click()");await waitFor('預覽已取消');assert.equal(await contents.executeJavaScript("document.querySelector('#title').value"),'');
    await js("document.querySelector('#form-preview-button').click()");await waitFor('尚未填入');
    await contents.executeJavaScript("window.fixtureEvents={input:0,change:0};document.querySelector('#practice-form').addEventListener('input',()=>fixtureEvents.input++);document.querySelector('#practice-form').addEventListener('change',()=>fixtureEvents.change++)");
    await js("document.querySelector('#form-confirm').click()");await waitFor('已填入並核對');
    const result=JSON.parse(await js("document.querySelector('#form-result').textContent"));
    assert.equal(result.submitted,'0');assert.equal(result.fields[0].value,book.title);assert.equal(result.fields[2].value,book.description);
    assert.deepEqual(JSON.parse(result.fields[3].value),book.keywords);assert.deepEqual(await contents.executeJavaScript('fixtureEvents'),{input:4,change:4});
    assert.equal(await contents.executeJavaScript("document.querySelector('#submitted').dataset.count"),'0');
    await capture('form-readback');await captureResult(contents,'form-filled');
    // 另行驗證頁面的人工按鈕，與產品的填入命令分開。
    await contents.executeJavaScript("document.querySelector('#practice-form button[type=submit]').click()");
    assert.equal(await contents.executeJavaScript("document.querySelector('#submitted').dataset.count"),'1');
    await captureResult(contents,'form-manual-submit');
    console.log('CHAPTER 14 MANUAL BUTTON PASS: separate local button click increments submitted from 0 to 1');
    await js("document.querySelector('#form-preview-button').click()");await waitFor('尚未填入');
    const second=newTab();await second.view.webContents.loadURL(practice.origin+'/');
    await js("document.querySelector('#form-confirm').click()");await waitFor('預覽已失效');assert.equal(await second.view.webContents.executeJavaScript("document.querySelector('#title').value"),'');
    switchTab(first.id);
    await js("document.querySelector('#form-preview-button').click()");await waitFor('尚未填入');books.save({...book,description:'人工修改'});
    await js("document.querySelector('#form-confirm').click()");await waitFor('書籍已變更');assert.equal(await contents.executeJavaScript("document.querySelector('#description').value"),book.description);
    await contents.loadURL('about:blank');await js("document.querySelector('#form-preview-button').click()");await waitFor('僅允許');
    console.log('CHAPTER 14 PASS: preview without write, cancel, confirmed fill, input/change events, readback, no submit, changed tab/book rejected, other origin rejected');
  } finally {clearTimeout(timer);window.close();}
}
module.exports={run};
