const assert=require('node:assert/strict');
const {captureResult}=require('../tools/capture-result');
async function run({app,window,aiClient,books}) {
  const timer=setTimeout(()=>app.exit(1),20000);
  const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text) {
    await js(`new Promise((resolve,reject)=>{const timer=setTimeout(()=>{clearInterval(poll);reject(new Error('文案介面逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#copy-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timer);clearInterval(poll);resolve();}},20);})`);
  }
  async function capture(name,selector='#book-copy-panel') {
    await js(`document.querySelector(${JSON.stringify(selector)}).scrollIntoView();new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))`);
    const box=await js(`(()=>{const b=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()`);
    assert.ok(box.y>=184 && box.y+box.height<=window.getContentSize()[1]);
    await captureResult(window.webContents,name,{x:0,y:box.y,width:300,height:box.height});
  }
  try {
    window.setContentSize(1200,1400);window.showInactive();
    const book=books.save({title:'文案練習書',author:'範例作者',description:'原稿：介紹工作瀏覽器實作。',keywords:['Electron']});
    await js(`selectBook(${JSON.stringify(book)});window.browser.command('ai-config',{model:'offline-model',key:'offline-fixture-not-a-real-key'})`);
    aiClient.fetcher=async(_url,options)=>{
      const body=JSON.parse(options.body);assert.equal(body.text.format.strict,true);
      return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'{"description":"離線測試建議：逐步練習工作瀏覽器實作。","keywords":["Electron","實作"]}'}]}]})};
    };
    await js("document.querySelector('#copy-generate').click()");await waitFor('建議已產生');
    assert.equal(books.get(book.id).description,book.description);await capture('copy-preview');
    await js("document.querySelector('#copy-discard').click()");await waitFor('已放棄');assert.equal(books.get(book.id).description,book.description);
    await js("document.querySelector('#copy-generate').click()");await waitFor('建議已產生');
    books.save({...book,description:'人工修改的新原稿'});
    await js("document.querySelector('#copy-apply').click()");await waitFor('原稿已變更');
    assert.equal(books.get(book.id).description,'人工修改的新原稿');await capture('copy-conflict');
    await js("document.querySelector('#copy-generate').click()");await waitFor('建議已產生');
    const other=books.save({title:'另一筆書籍',description:'另一筆原稿',keywords:[]});await js(`selectBook(${JSON.stringify(other)})`);
    await js("document.querySelector('#copy-apply').click()");await waitFor('已保存建議');
    assert.match(books.get(book.id).description,/離線測試建議/);assert.equal(books.get(other.id).description,'另一筆原稿');
    await capture('copy-saved');
    await capture('copy-saved-fields','#book-form');
    aiClient.fetcher=async()=>({ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'{"description":3,"keywords":[]}'}]}]})});
    const before=books.get(book.id);await js("document.querySelector('#copy-generate').click()");await waitFor('格式不正確');
    assert.deepEqual(books.get(book.id),before);assert.equal(await js("document.querySelector('#copy-preview').hidden"),true);
    console.log('CHAPTER 12 PASS: strict schema, original unchanged, discard, changed-original rejection, target retained across selection, confirmed save, invalid response; offline API');
  } finally {aiClient.cancel();clearTimeout(timer);window.close();}
}
module.exports={run};
