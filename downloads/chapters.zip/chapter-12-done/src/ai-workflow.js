const { randomUUID } = require('node:crypto');
const { normalizeUrl } = require('./url');
class AiWorkflow {
  constructor(client, books) { this.client = client; this.books = books; this.pagePreview = null; this.suggestion = null; this.generation = 0; }
  previewPage(value) {
    const url = normalizeUrl(value?.url);
    if (!url || typeof value.text !== 'string' || !value.text.trim()) throw new Error('此頁沒有可摘要文字。');
    const token = randomUUID(); const text = value.text.trim().slice(0, 12000);
    this.pagePreview = { token, text, url, title: String(value.title || '').slice(0, 200), created: Date.now() };
    return { ...this.pagePreview, truncated: value.text.trim().length > text.length };
  }
  async summarize(token) {
    if (this.client.busy) throw new Error('AI 請求進行中，請等待或取消。');
    const preview = this.pagePreview;
    if (!preview || preview.token !== token || Date.now() - preview.created > 600000) throw new Error('摘要預覽已失效，請重新擷取。');
    this.pagePreview = null;
    const text = await this.client.request(preview.text);
    return { text, sourceUrl: preview.url, sourceTitle: preview.title };
  }
  async rewrite(id) {
    if (this.client.busy) throw new Error('AI 請求進行中，請等待或取消。');
    if (typeof id !== 'string') throw new Error('請先選擇已儲存的書籍。');
    const original = this.books.get(id); if (!original) throw new Error('書籍已不存在，請重新選擇。');
    this.suggestion = null;
    const generation = ++this.generation;
    const proposed = await this.client.request(JSON.stringify({ title: original.title, author: original.author, description: original.description, keywords: original.keywords }), true);
    if (generation !== this.generation) throw new Error('已放棄本次文案建議。');
    const token = randomUUID(); this.suggestion = { token, original, proposed };
    return { token, original, proposed };
  }
  apply(token) {
    const suggestion = this.suggestion;
    if (!suggestion || suggestion.token !== token) throw new Error('文案建議已失效，請重新產生。');
    const current = this.books.get(suggestion.original.id);
    if (!current || JSON.stringify(current) !== JSON.stringify(suggestion.original)) throw new Error('原稿已變更，請重新產生建議，避免覆寫新的資料。');
    const saved = this.books.save({ ...current, ...suggestion.proposed }); this.suggestion = null;
    return saved;
  }
  discard() { this.generation++; this.suggestion = null; this.pagePreview = null; }
}
module.exports = { AiWorkflow };
