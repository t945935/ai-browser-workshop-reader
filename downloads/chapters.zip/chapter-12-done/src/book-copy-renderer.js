(() => {
  const find=id=>document.querySelector(`#${id}`);
  let token,waiting=false,generation=0;
  const status=find('copy-status');
  async function invoke(command,input) {
    const result=await window.browser.command(command,input);
    if(result.error) throw new Error(result.error);
    return result;
  }
  function busy(value) {
    waiting=value;find('copy-generate').disabled=value;find('copy-apply').disabled=value;
    find('copy-cancel').disabled=!value;
  }
  find('copy-generate').addEventListener('click',async()=>{
    if(waiting) return;
    const current=++generation;token=undefined;find('copy-preview').hidden=true;
    busy(true);status.textContent='等待文案建議…';
    try {
      const {suggestion}=await invoke('ai-rewrite',selectedBookId);
      if(current!==generation) return;
      token=suggestion.token;find('copy-target').textContent=`目標書籍：${suggestion.original.title}`;
      find('copy-original').textContent=JSON.stringify({description:suggestion.original.description,keywords:suggestion.original.keywords},null,2);
      find('copy-proposed').textContent=JSON.stringify(suggestion.proposed,null,2);
      find('copy-preview').hidden=false;status.textContent='建議已產生，原稿尚未變更。';
    } catch(error) {if(current===generation) status.textContent=error.message;}
    finally {busy(false);}
  });
  find('copy-apply').addEventListener('click',async()=>{
    if(waiting || !token) return;
    busy(true);
    try {
      const {book}=await invoke('ai-apply',token);
      token=undefined;find('copy-preview').hidden=true;selectBook(book);await loadBooks();
      status.textContent=`已保存建議：${book.title}。`;
    } catch(error) {status.textContent=error.message;}
    finally {busy(false);}
  });
  find('copy-discard').addEventListener('click',async()=>{
    ++generation;token=undefined;find('copy-preview').hidden=true;
    try {await invoke('ai-discard');status.textContent='已放棄建議，書籍未因放棄而變更。';}
    catch(error) {status.textContent=error.message;}
  });
  find('copy-cancel').addEventListener('click',async()=>{
    try {await invoke('ai-cancel');} catch(error) {status.textContent=error.message;}
  });
})();
