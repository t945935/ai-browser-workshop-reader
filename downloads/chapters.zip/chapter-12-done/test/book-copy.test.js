const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {AiClient,validateSuggestion}=require('../src/ai-client');
const {AiWorkflow}=require('../src/ai-workflow');
const {BookStore}=require('../src/books');
test('文案拒絕無效 JSON、錯誤型別、缺欄位、額外欄位與過長內容',()=>{
  for(const value of ['broken','{"description":3,"keywords":[]}','{"description":"內容","keywords":"AI"}','{"description":"內容"}','{"description":"內容","keywords":[],"title":"任意"}',JSON.stringify({description:'字'.repeat(20001),keywords:[]})]) assert.throws(()=>validateSuggestion(value));
  assert.deepEqual(validateSuggestion('{"description":"建議","keywords":["含,逗號"]}'),{description:'建議',keywords:['含,逗號']});
});
test('文案要求 strict schema，但應用程式仍拒絕無效回應',async()=>{
  let body;
  const client=new AiClient({model:'offline',getKey:()=> 'offline-fixture'},async(_url,options)=>{
    body=JSON.parse(options.body);return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'{"description":3,"keywords":[]}'}]}]})};
  });
  await assert.rejects(client.request('原稿',true),/格式不正確/);
  assert.equal(body.text.format.strict,true);assert.equal(body.text.format.schema.additionalProperties,false);
  assert.deepEqual(body.text.format.schema.required,['description','keywords']);assert.equal(client.busy,false);
});
test('建議確認前不保存；原稿修改或刪除拒絕；token 只用一次',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'chapter12-copy-'));const books=new BookStore(directory);
  try {
    const original=books.save({title:'範例',description:'原稿',keywords:[]});
    const workflow=new AiWorkflow({busy:false,request:async()=>({description:'離線建議',keywords:['AI']})},books);
    let suggestion=await workflow.rewrite(original.id);assert.equal(books.get(original.id).description,'原稿');
    workflow.discard();assert.throws(()=>workflow.apply(suggestion.token),/失效/);assert.equal(books.get(original.id).description,'原稿');
    suggestion=await workflow.rewrite(original.id);books.save({...original,description:'人工修改'});
    assert.throws(()=>workflow.apply(suggestion.token),/已變更/);assert.equal(books.get(original.id).description,'人工修改');
    suggestion=await workflow.rewrite(original.id);const saved=workflow.apply(suggestion.token);
    assert.equal(saved.description,'離線建議');assert.equal(saved.id,original.id);assert.equal(saved.title,original.title);
    assert.throws(()=>workflow.apply(suggestion.token),/失效/);
    suggestion=await workflow.rewrite(original.id);books.delete(original.id);assert.throws(()=>workflow.apply(suggestion.token),/已變更/);
  } finally {books.close();}
});
test('等待中放棄後，晚到回應不能重新成為可保存建議',async()=>{
  let finish;const book={id:'id',title:'範例',description:'原稿',keywords:[]};
  const workflow=new AiWorkflow({busy:false,request:()=>new Promise(resolve=>{finish=resolve;})},{get:()=>book});
  const pending=workflow.rewrite('id');workflow.discard();finish({description:'晚到',keywords:[]});
  await assert.rejects(pending,/已放棄/);assert.equal(workflow.suggestion,null);
});
