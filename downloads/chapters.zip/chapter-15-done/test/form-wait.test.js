const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {FormWorkflow}=require('../src/form-workflow');
test('成功及失敗均記錄階段，不含書籍內容；busy 恢復',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'chapter15-log-'));
  const url='http://127.0.0.1:1234/';const book={title:'私人書名',description:'私人內容',keywords:[]};
  const workflow=new FormWorkflow({allows:()=>true},{get:()=>book},directory,100);
  const contents={id:1,getURL:()=>url,isDestroyed:()=>false,executeJavaScript:async()=>({fields:[],submitted:'0'})};
  let preview=await workflow.preview(contents,'id');await workflow.fill(contents,preview.token);
  contents.executeJavaScript=async()=>({error:'等待欄位逾時；請檢查延遲或缺少欄位模式。'});
  await assert.rejects(workflow.preview(contents,'id'),/逾時/);assert.equal(workflow.busy,false);
  const raw=fs.readFileSync(workflow.logFile,'utf8'),lines=raw.trim().split('\n').map(JSON.parse);
  assert.equal(raw.includes('私人'),false);assert.deepEqual(lines.map(line=>[line.action,line.status]),[['preview','ok'],['fill','ok'],['preview','failed']]);
  assert.ok(lines.every(line=>Object.keys(line).sort().join(',')==='action,at,status'));
});
test('頁面執行未回覆也有外層逾時，變更網址即停止',async()=>{
  const url='http://127.0.0.1:1234/';let current=url;
  const workflow=new FormWorkflow({allows:()=>true},{get:()=>({title:'範例',keywords:[]})},undefined,10);
  const contents={id:1,getURL:()=>current,isDestroyed:()=>false,executeJavaScript:()=>new Promise(()=>{})};
  await assert.rejects(workflow.preview(contents,'id'),/逾時/);assert.equal(workflow.busy,false);
  workflow.timeoutMs=1000;const pending=workflow.preview(contents,'id');current='about:blank';
  await assert.rejects(pending,/已變更/);assert.equal(workflow.busy,false);
});
