const fs=require('node:fs');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {readFields}=require('./dom-reader');
// 固定函式在示範網頁執行，readFields 由固定程式碼一同注入。
function fillFields(expectedUrl,payload) {
  const before=readFields(expectedUrl);if(before.error)return before;
  const entries=before.fields.map(field=>{
    const element=document.getElementById(field.id);
    const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element),'value')?.set;
    return {field,element,setter};
  });
  if(entries.some(({element,setter})=>!setter || (element.tagName==='INPUT' && element.type!=='text')))return {error:'欄位型別不支援。'};
  for(const {field,element,setter} of entries) {
    if(location.href!==expectedUrl)return {error:'示範頁面已變更。'};
    setter.call(element,payload[field.id]);
    element.dispatchEvent(new Event('input',{bubbles:true}));
    element.dispatchEvent(new Event('change',{bubbles:true}));
  }
  const after=readFields(expectedUrl);if(after.error)return after;
  if(after.fields.some(field=>field.value!==payload[field.id]))return {error:'填入後欄位值不一致，請人工核對。'};
  return after;
}
async function inspectFields(expectedUrl,payload,timeoutMs) {
  const started=Date.now();
  while(Date.now()-started<timeoutMs) {
    if(location.href!==expectedUrl || document.body?.dataset.practice!=='ai-browser-workshop-v1')return {error:'示範頁面已變更。'};
    const result=readFields(expectedUrl);
    if(!result.error)return payload ? fillFields(expectedUrl,payload) : result;
    if(!/^(找不到欄位|欄位不可操作)/.test(result.error))return result;
    await new Promise(resolve=>setTimeout(resolve,50));
  }
  return {error:'等待欄位逾時；請檢查延遲或缺少欄位模式。'};
}
class FormWorkflow {
  constructor(server,books,directory,timeoutMs=5000){this.server=server;this.books=books;this.pending=null;this.busy=false;this.timeoutMs=timeoutMs;this.logFile=directory ? path.join(directory,'operation-log.jsonl') : null;}
  log(action,status){if(this.logFile)fs.appendFileSync(this.logFile,JSON.stringify({at:new Date().toISOString(),action,status})+'\n','utf8');}
  async inspect(contents,payload=null) {
    const url=contents.getURL();if(!this.server.allows(url))throw new Error('自動填表僅允許本次啟動的本機示範網站。');
    const script=`(()=>{const readFields=${readFields.toString()};const fillFields=${fillFields.toString()};return (${inspectFields.toString()})(${JSON.stringify(url)},${JSON.stringify(payload)},${this.timeoutMs});})()`;
    let heartbeat;const started=Date.now();
    try {
      const operation=contents.executeJavaScript(script);
      const monitor=new Promise((_resolve,reject)=>{heartbeat=setInterval(()=>{
        if(contents.isDestroyed() || contents.getURL()!==url)reject(new Error('page-changed'));
        else if(Date.now()-started>this.timeoutMs+250)reject(new Error('operation-timeout'));
      },50);});
      const result=await Promise.race([operation,monitor]);
      if(result.error)throw new Error(result.error);
      return {...result,url};
    } catch(error) {
      if(error.message==='page-changed')throw new Error('示範頁面已變更，請重新預覽。');
      if(error.message==='operation-timeout')throw new Error('等待欄位逾時；請檢查頁面是否仍可操作。');
      if(/^(等待欄位逾時|示範頁面已變更|欄位|填入後)/.test(error.message))throw error;
      throw new Error('頁面操作中斷，請重新開啟示範網站。');
    } finally {clearInterval(heartbeat);}
  }
  async preview(contents,id) {
    if(this.busy)throw new Error('表單操作進行中，請稍候。');
    if(typeof id!=='string')throw new Error('請先選擇已儲存的書籍。');
    const book=this.books.get(id);if(!book)throw new Error('書籍已不存在。');
    this.busy=true;this.pending=null;
    try {
      const result=await this.inspect(contents);const token=randomUUID();
      const values={title:book.title,author:book.author,description:book.description,keywords:JSON.stringify(book.keywords)};
      this.pending={token,book,url:result.url,contentsId:contents.id,values,created:Date.now()};
      this.log('preview','ok');return {token,url:result.url,fields:Object.entries(values).map(([id,value])=>({id,value}))};
    } catch(error){this.log('preview','failed');throw error;} finally {this.busy=false;}
  }
  async fill(contents,token) {
    if(this.busy)throw new Error('表單操作進行中，請稍候。');
    const pending=this.pending;
    if(!pending || pending.token!==token || pending.contentsId!==contents.id || pending.url!==contents.getURL() || Date.now()-pending.created>600000)throw new Error('填表預覽已失效，請重新預覽。');
    if(JSON.stringify(this.books.get(pending.book.id))!==JSON.stringify(pending.book))throw new Error('書籍已變更，請重新預覽。');
    this.busy=true;this.pending=null;
    try {const result=await this.inspect(contents,pending.values);this.log('fill','ok');return {fields:result.fields,submitted:result.submitted};}
    catch(error){this.log('fill','failed');throw error;}
    finally {this.busy=false;}
  }
  discard(){this.pending=null;}
}
module.exports={FormWorkflow,fillFields};
