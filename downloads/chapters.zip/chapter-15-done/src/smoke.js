const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const {captureResult}=require('../tools/capture-result');
async function run({app,window,active,practice,books,forms}) {
  const timer=setTimeout(()=>app.exit(1),30000);const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text){await js(`new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('等待介面逾時'));},6500);const poll=setInterval(()=>{if(document.querySelector('#form-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timeout);clearInterval(poll);resolve();}},20);})`);}
  async function capture(name){
    await js("document.querySelector('#form-panel').scrollIntoView();new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
    const box=await js("(()=>{const b=document.querySelector('#form-panel').getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()");
    await captureResult(window.webContents,name,{x:0,y:box.y,width:300,height:box.height});
  }
  try {
    window.setContentSize(1200,1200);window.showInactive();const contents=active().view.webContents;
    const book=books.save({title:'等待練習書',author:'範例作者',description:'這段簡介不應進入日誌。',keywords:['等待']});
    await js(`selectBook(${JSON.stringify(book)})`);await contents.loadURL(practice.origin+'/?mode=delay');
    const delayStarted=Date.now();await js("document.querySelector('#form-preview-button').click()");
    assert.equal(await js("document.querySelector('#form-preview-button').disabled"),true);await capture('form-waiting');
    const blocked=await js(`window.browser.command('books-save',${JSON.stringify({...book,title:'等待中不應保存'})})`);
    assert.match(blocked.error,/操作進行中/);assert.equal(books.get(book.id).title,book.title);
    assert.match((await js("window.browser.command('ai-apply','invalid-token')")).error,/操作進行中/);
    await waitFor('尚未填入');assert.ok(Date.now()-delayStarted>=1300);assert.equal(forms.busy,false);
    await capture('form-delay-ready');
    await js("document.querySelector('#form-confirm').click()");await waitFor('已填入並核對');
    assert.equal(await contents.executeJavaScript("document.querySelector('#title').value"),book.title);
    assert.equal(await contents.executeJavaScript("document.querySelector('#submitted').dataset.count"),'0');
    await contents.loadURL(practice.origin+'/?mode=missing');const missingStarted=Date.now();
    await js("document.querySelector('#form-preview-button').click()");await waitFor('等待欄位逾時');
    assert.ok(Date.now()-missingStarted>=4800);assert.equal(forms.busy,false);
    assert.equal(await js("document.querySelector('#form-preview-button').disabled"),false);await capture('form-timeout');
    await contents.loadURL(practice.origin+'/?mode=missing');
    await js("document.querySelector('#form-preview-button').click()");await waitFor('讀取欄位');
    await contents.loadURL('about:blank');await waitFor('頁面');assert.equal(forms.busy,false);
    await contents.loadURL(practice.origin+'/');await js("document.querySelector('#form-preview-button').click()");await waitFor('尚未填入');
    const lines=fs.readFileSync(forms.logFile,'utf8').trim().split('\n').map(line=>JSON.parse(line));
    assert.ok(lines.some(line=>line.action==='preview' && line.status==='failed'));
    assert.ok(lines.some(line=>line.action==='fill' && line.status==='ok'));
    assert.ok(lines.every(line=>Object.keys(line).sort().join(',')==='action,at,status'));
    assert.equal(JSON.stringify(lines).includes(book.description),false);assert.equal(JSON.stringify(lines).includes(book.title),false);
    const directory=path.join(app.getAppPath(),'assets/results');fs.mkdirSync(directory,{recursive:true});
    fs.writeFileSync(path.join(directory,'operation-log.json'),JSON.stringify(lines,null,2));
    console.log('CHAPTER 15 PASS: actual delayed fields, five-second missing-field timeout, changed-page stop, busy and buttons restored, normal retry, metadata-only operation log, no submit');
  } finally {clearTimeout(timer);window.close();}
}
module.exports={run};
