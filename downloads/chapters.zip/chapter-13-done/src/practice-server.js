const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
class PracticeServer {
  constructor(directory) { this.directory = directory; this.origin = ''; this.server = null; }
  async start() {
    const routes = { '/': ['index.html', 'text/html'], '/practice.js': ['practice.js', 'text/javascript'], '/style.css': ['style.css', 'text/css'] };
    this.server = http.createServer((request, response) => {
      try {
        const route = routes[new URL(request.url, 'http://127.0.0.1').pathname];
        if (request.method !== 'GET' || !route) { response.writeHead(404); response.end('Not found'); return; }
        response.writeHead(200, { 'Content-Type': `${route[1]}; charset=utf-8`, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
        response.end(fs.readFileSync(path.join(this.directory, route[0])));
      } catch { response.writeHead(500); response.end('Practice page unavailable'); }
    });
    await new Promise((resolve, reject) => { this.server.once('error', reject); this.server.listen(0, '127.0.0.1', resolve); });
    this.origin = `http://127.0.0.1:${this.server.address().port}`; return this.origin;
  }
  allows(value) { try { const url = new URL(value); return url.origin === this.origin && url.pathname === '/'; } catch { return false; } }
  close() { this.server?.close(); }
}
module.exports = { PracticeServer };
