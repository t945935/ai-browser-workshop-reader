// 第 13 章只讀取欄位，不包含填入、提交或等待迴圈。
function readFields(expectedUrl) {
  if(location.href!==expectedUrl || document.body?.dataset.practice!=='ai-browser-workshop-v1') return {error:'示範頁面已變更。'};
  const fields=[];
  for(const id of ['title','author','description','keywords']) {
    const element=document.getElementById(id);
    if(!element) return {error:`找不到欄位：${id}。`};
    const tag=id==='description'?'TEXTAREA':'INPUT';
    if(element.tagName!==tag || element.disabled || element.readOnly || !element.getClientRects().length) return {error:`欄位不可操作：${id}。`};
    for(let node=element;node;node=node.parentElement) {
      const style=getComputedStyle(node);
      if(style.visibility==='hidden' || style.visibility==='collapse' || style.opacity==='0') return {error:`欄位不可操作：${id}。`};
    }
    fields.push({id,tag:element.tagName.toLowerCase(),value:element.value});
  }
  return {fields,submitted:document.querySelector('#submitted')?.dataset.count || '0'};
}
class DomReader {
  constructor(server){this.server=server;}
  async read(contents) {
    const url=contents.getURL();
    if(!this.server.allows(url)) throw new Error('讀取欄位僅允許本次啟動的本機示範網站。');
    let result;
    try {result=await contents.executeJavaScript(`(${readFields.toString()})(${JSON.stringify(url)})`);}
    catch {throw new Error('頁面讀取中斷，請重新開啟示範網站。');}
    if(contents.isDestroyed() || contents.getURL()!==url) throw new Error('示範頁面已變更。');
    if(result.error) throw new Error(result.error);
    return {...result,url};
  }
}
module.exports={DomReader,readFields};
