(() => {
  const find=id=>document.querySelector(`#${id}`);
  async function invoke(command) {
    const result=await window.browser.command(command);
    if(result.error) throw new Error(result.error);
    return result;
  }
  find('practice-open').addEventListener('click',async()=>{
    try {await invoke('practice-open');find('dom-output').textContent='';find('dom-status').textContent='已要求開啟，等頁面載入後再讀取。';}
    catch(error){find('dom-status').textContent=error.message;}
  });
  find('practice-read').addEventListener('click',async()=>{
    find('practice-read').disabled=true;find('dom-output').textContent='';
    try {
      const result=await invoke('dom-read');find('dom-output').textContent=JSON.stringify(result,null,2);
      find('dom-status').textContent='欄位已讀取，沒有填入或提交。';
    } catch(error){find('dom-status').textContent=error.message;}
    finally {find('practice-read').disabled=false;}
  });
})();
