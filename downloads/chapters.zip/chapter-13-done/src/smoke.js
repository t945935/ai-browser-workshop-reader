const assert=require('node:assert/strict');
const {captureResult}=require('../tools/capture-result');
async function run({app,window,active,practice}) {
  const timer=setTimeout(()=>app.exit(1),20000);
  const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text) {
    await js(`new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('DOM 介面逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#dom-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timeout);clearInterval(poll);resolve();}},20);})`);
  }
  try {
    window.setContentSize(1200,1100);window.showInactive();
    const contents=active().view.webContents;
    const loaded=new Promise(resolve=>contents.once('did-finish-load',resolve));
    await js("document.querySelector('#practice-open').click()");await loaded;
    await contents.executeJavaScript("document.querySelector('#title').value='DOM 練習書';document.querySelector('#author').value='範例作者';document.querySelector('#description').value='第一行\\n第二行';document.querySelector('#keywords').value='[\"DOM\",\"欄位\"]'");
    await js("document.querySelector('#practice-read').click()");await waitFor('欄位已讀取');
    const result=JSON.parse(await js("document.querySelector('#dom-output').textContent"));
    assert.equal(result.fields[0].value,'DOM 練習書');assert.equal(result.fields[1].value,'範例作者');
    assert.equal(result.fields[2].tag,'textarea');assert.equal(result.fields[2].value,'第一行\n第二行');assert.equal(result.submitted,'0');
    await captureResult(contents,'practice-fields');
    await js("document.querySelector('#dom-panel').scrollIntoView();new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))");
    const box=await js("(()=>{const b=document.querySelector('#dom-panel').getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()");
    assert.ok(box.y>=184 && box.y+box.height<=window.getContentSize()[1]);
    await captureResult(window.webContents,'dom-read-result',{x:0,y:box.y,width:300,height:box.height});
    await contents.executeJavaScript("document.querySelector('#author').readOnly=true");
    assert.match((await js("window.browser.command('dom-read')")).error,/不可操作/);
    await contents.executeJavaScript("document.querySelector('#author').readOnly=false;document.querySelector('#author').style.visibility='hidden'");
    assert.match((await js("window.browser.command('dom-read')")).error,/不可操作/);
    await contents.executeJavaScript("document.querySelector('#author').style.visibility='visible';document.querySelector('#fields').style.opacity='0'");
    assert.match((await js("window.browser.command('dom-read')")).error,/不可操作/);
    await contents.loadURL(practice.origin+'/?mode=missing');
    assert.match((await js("window.browser.command('dom-read')")).error,/找不到欄位：author/);
    await contents.loadURL(practice.origin+'/?mode=delay');
    assert.match((await js("window.browser.command('dom-read')")).error,/找不到欄位/);
    await contents.executeJavaScript("new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{clearInterval(poll);reject(new Error('示範欄位逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#author')){clearTimeout(timeout);clearInterval(poll);resolve();}},20);})");
    assert.equal((await js("window.browser.command('dom-read')")).fields.length,4);
    await contents.loadURL('about:blank');assert.match((await js("window.browser.command('dom-read')")).error,/僅允許/);
    console.log('CHAPTER 13 PASS: loopback practice page, actual DOM read, values and textarea, no submit, readonly and hidden rejection, missing and delayed fields, other origin rejected');
  } finally {clearTimeout(timer);window.close();}
}
module.exports={run};
