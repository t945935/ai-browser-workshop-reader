const mode = new URL(location.href).searchParams.get('mode');
const fields = document.querySelector('#fields');
function createFields() {
  fields.append(document.querySelector('#field-template').content.cloneNode(true));
  if (mode === 'missing') { document.querySelector('label[for="author"]').remove(); document.querySelector('#author').remove(); }
  document.querySelector('#mode-status').textContent = mode === 'missing' ? '缺少作者欄位，用於測試錯誤。' : '欄位已準備。';
}
if (mode === 'delay') { document.querySelector('#mode-status').textContent = '欄位將於兩秒後出現。'; setTimeout(createFields, 2000); }
else createFields();
document.querySelector('#practice-form').addEventListener('submit', event => {
  event.preventDefault();
  const output = document.querySelector('#submitted'); output.dataset.count = String(Number(output.dataset.count) + 1);
  output.textContent = '已人工提交本機示範資料；未送往外部網站。';
});
