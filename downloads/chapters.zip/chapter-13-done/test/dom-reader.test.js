const {test}=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const {PracticeServer}=require('../src/practice-server');
const {DomReader}=require('../src/dom-reader');
test('示範伺服器只提供固定路徑；讀取拒絕外部來源與錯誤頁面',async()=>{
  const server=new PracticeServer(path.join(__dirname,'../practice-site'));
  try {
    const origin=await server.start();assert.equal((await fetch(origin+'/')).status,200);
    assert.equal((await fetch(origin+'/unknown')).status,404);
    assert.equal((await fetch(origin+'/',{method:'POST'})).status,404);
    assert.equal(server.allows(origin+'/?mode=delay'),true);assert.equal(server.allows(origin+'/other'),false);
    const reader=new DomReader(server);
    await assert.rejects(reader.read({getURL:()=> 'https://example.com',executeJavaScript:()=>{throw new Error('不應執行');}}),/僅允許/);
    await assert.rejects(reader.read({getURL:()=>origin+'/',isDestroyed:()=>false,executeJavaScript:async()=>({error:'示範頁面已變更。'})}),/已變更/);
  } finally {server.close();}
});
