// 擷取實際渲染內容；UI 與 WebContentsView 分別存圖，不合成示意畫面。
const fs = require('node:fs');
const path = require('node:path');
const { app } = require('electron');
async function captureResult(contents, name, rectangle) {
  // 隱藏的 WebContentsView 可能暫停 requestAnimationFrame，不能以它作為等待條件。
  await contents.executeJavaScript("document.fonts.ready.then(()=>new Promise(resolve=>setTimeout(resolve,150)))");
  let image;
  for(let attempt=0;attempt<3;attempt++) {
    try {image=await contents.capturePage(rectangle);break;}
    catch(error) {
      if(!String(error.message).includes('UnknownVizError') || attempt===2) throw new Error(`結果截圖失敗 ${name}：${error.message}`);
      // 視窗剛顯示時，原生子檢視的合成畫面偶爾尚未準備好；仍需取得真實圖像。
      await new Promise(resolve=>setTimeout(resolve,200));
    }
  }
  if (image.isEmpty()) throw new Error('執行結果截圖為空。');
  const directory = path.join(app.getAppPath(),'assets/results');
  fs.mkdirSync(directory,{recursive:true});
  fs.writeFileSync(path.join(directory,`${name}.png`),image.toPNG());
}
module.exports = { captureResult };
