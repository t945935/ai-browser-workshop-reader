const address = document.querySelector('#address');
const status = document.querySelector('#status');
function button(text, handler) {
  const element = document.createElement('button'); element.type = 'button'; element.textContent = text;
  element.addEventListener('click', handler); return element;
}
function render(state) {
  if (document.activeElement !== address) address.value = state.url;
  document.querySelector('#back').disabled = !state.canGoBack;
  document.querySelector('#forward').disabled = !state.canGoForward;
  document.querySelector('#reload').disabled = !state.url;
  status.textContent = state.message || (state.loading ? '正在載入…' : state.title || '就緒');
  document.querySelector('#panel').hidden = !state.settings.panelVisible;
  document.querySelector('#reset-settings').hidden = !state.settingsError;
  document.querySelector('#data-path').textContent = state.dataPath;
  document.querySelector('#tabs').replaceChildren(...state.tabs.map(tab => {
    const item = document.createElement('div'); item.className = `tab${tab.id === state.activeId ? ' active' : ''}`;
    const select = button(tab.title, () => command('switch-tab', tab.id)); select.setAttribute('aria-pressed', String(tab.id === state.activeId));
    const close = button('×', () => command('close-tab', tab.id)); close.setAttribute('aria-label', `關閉 ${tab.title}`);
    item.append(select, close); return item;
  }));
  document.querySelector('#favorites').replaceChildren(...state.settings.favorites.map(favorite => {
    const row = document.createElement('div'); row.className = 'favorite';
    const open = button(favorite.title, () => command('navigate', favorite.url)); open.title = favorite.url;
    const remove = button('×', () => command('remove-favorite', favorite.url)); remove.setAttribute('aria-label', `移除 ${favorite.title}`);
    row.append(open, remove); return row;
  }));
}
async function command(action, input) {
  try { render(await window.browser.command(action, input)); }
  catch { status.textContent = '操作失敗，請重新啟動程式。'; }
}
window.browser.onState(render);
document.querySelector('#navigation').addEventListener('submit', event => {
  event.preventDefault();
  address.blur();
  command('navigate', address.value);
});
for (const action of ['back', 'forward', 'reload', 'new-tab', 'add-favorite', 'toggle-panel', 'reset-settings']) {
  document.querySelector(`#${action}`).addEventListener('click', () => command(action));
}
command('state');
