const { normalizeUrl } = require('./url');
function defaults() { return { version: 1, favorites: [], panelVisible: true }; }
function validateSettings(value) {
  if (!value || value.version !== 1 || !Array.isArray(value.favorites) || typeof value.panelVisible !== 'boolean' || value.favorites.length > 100) throw new Error('設定格式不正確。');
  const favorites = value.favorites.map(item => {
    if (!item || typeof item.title !== 'string' || !item.title.trim() || item.title.length > 200) throw new Error('網站名稱不正確。');
    const url = normalizeUrl(item.url); if (!url) throw new Error('網站網址不可空白。');
    return { title: item.title.trim(), url };
  });
  if (new Set(favorites.map(item => item.url)).size !== favorites.length) throw new Error('網站網址重複。');
  return { version: 1, favorites, panelVisible: value.panelVisible };
}
// 第 6、7 章只有記憶體狀態；第 8 章才改成 JSON 檔案。
class SettingsStore {
  constructor() { this.value = defaults(); this.error = ''; }
  save(value) { this.value = validateSettings(value); }
  reset() { this.value = defaults(); }
}
module.exports = { SettingsStore, validateSettings };
