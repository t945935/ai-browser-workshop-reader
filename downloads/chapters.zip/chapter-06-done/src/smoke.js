const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { SettingsStore } = require('./settings');
async function run({ app, window, tabs, active, state, newTab, switchTab, closeTab, resize }) {
  const timer = setTimeout(() => { console.error('SMOKE FAIL: timeout'); app.exit(1); }, 20000);
  const server = http.createServer((request, response) => response.end(`<!doctype html><title>${request.url === '/second' ? 'Second' : 'First'}</title><p>本機驗收頁面</p>`));
  try {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); const base = `http://127.0.0.1:${server.address().port}`;
    assert.equal(await window.webContents.executeJavaScript("Boolean(window.browser && document.querySelector('#address'))"), true);
    const first = active(); await first.view.webContents.loadURL(base);
    const second = newTab(); await second.view.webContents.loadURL(`${base}/second`);
    assert.equal(state().title, 'Second'); switchTab(first.id); assert.equal(state().title, 'First');
    assert.equal(first.view.getVisible(), true); assert.equal(second.view.getVisible(), false);
    const favoriteState = await window.webContents.executeJavaScript("window.browser.command('add-favorite')");
    assert.equal(favoriteState.settings.favorites.length, 1);
    assert.equal(new SettingsStore().value.favorites.length, 0);
    await window.webContents.executeJavaScript("new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))");
    const image = await window.webContents.capturePage({ x: 0, y: 0, width: 1200, height: 184 });
    fs.mkdirSync(path.join(app.getAppPath(), 'assets/images'), { recursive: true });
    fs.writeFileSync(path.join(app.getAppPath(), 'assets/images/p2-toolbar.png'), image.toPNG());
    await window.webContents.executeJavaScript("window.browser.command('toggle-panel')"); resize(); assert.equal(first.view.getBounds().x, 0);
    const closedContents = second.view.webContents;
    const destroyed = new Promise(resolve => closedContents.once('destroyed', resolve));
    closeTab(second.id); await destroyed; assert.equal(closedContents.isDestroyed(), true);
    closeTab(first.id); assert.equal(tabs.size, 1); assert.equal(state().url, '');
    await active().view.webContents.loadURL(base);
    assert.equal(await active().view.webContents.executeJavaScript("typeof window.browser + ',' + typeof require"), 'undefined,undefined');
    await window.webContents.executeJavaScript("window.browser.command('toggle-panel')");
    console.log('CHAPTER 06 PASS: tabs, visibility, close lifecycle, memory favorites, panel layout, isolated external page');
  } finally { clearTimeout(timer); server.close(); window.close(); }
}
module.exports = { run };
