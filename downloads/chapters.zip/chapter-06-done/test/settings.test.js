const test = require('node:test');
const assert = require('node:assert/strict');
const { SettingsStore } = require('../src/settings');
test('記憶體偏好驗證後更新，重建與回復不保留收藏', () => {
  const store = new SettingsStore();
  const next = {version:1,favorites:[{title:' 範例 ',url:'example.com'}],panelVisible:false};
  store.save(next); next.favorites[0].title='外部修改';
  assert.equal(store.value.favorites[0].title,'範例');
  assert.equal(store.value.favorites[0].url,'https://example.com/');
  assert.equal(store.value.panelVisible,false);
  assert.throws(()=>store.save({...store.value,favorites:[{title:'錯誤',url:'javascript:alert(1)'}]}));
  assert.equal(store.value.favorites[0].title,'範例');
  assert.throws(()=>store.save({...store.value,favorites:[...store.value.favorites,...store.value.favorites]}),/重複/);
  assert.deepEqual(new SettingsStore().value,{version:1,favorites:[],panelVisible:true});
  store.reset(); assert.deepEqual(store.value,{version:1,favorites:[],panelVisible:true});
});
