# 第 3 章完成版

本章只有本機視窗與「檢查程序分工」按鈕。按下後，renderer 經 preload 呼叫主程序，再把回應顯示到畫面。尚未加入網頁檢視、網址列、資料庫或 AI。

在本目錄執行 `npm.cmd ci`，再執行 `npm.cmd start`。`npm.cmd run smoke` 自動核對按鈕、受控 IPC、未知操作拒絕與 renderer 沒有 require。
