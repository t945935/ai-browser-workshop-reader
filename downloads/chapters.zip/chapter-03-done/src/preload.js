const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('browser', {
  command: command => ipcRenderer.invoke('browser:command', command)
});
