const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const assert = require('node:assert/strict');
const smoke = process.argv.includes('--smoke-test');
if (smoke) app.setPath('userData', require('node:fs').mkdtempSync(path.join(require('node:os').tmpdir(),'chapter03-result-')));
const uiUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
let window;
ipcMain.handle('browser:command', (event, command) => {
  if (!window || event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame || event.senderFrame.url !== uiUrl) {
    throw new Error('不允許的操作來源。');
  }
  if (command !== 'ping') throw new Error('不支援的操作。');
  return { message: '主程序已收到操作。' };
});
function createWindow() {
  window = new BrowserWindow({ width: 900, height: 600, show: !smoke,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), nodeIntegration: false, contextIsolation: true, sandbox: true }
  });
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.once('did-finish-load', async () => {
    if (!smoke) return;
    try {
      assert.equal(await window.webContents.executeJavaScript('typeof require'), 'undefined');
      assert.equal(await window.webContents.executeJavaScript("document.querySelector('#status').textContent"), '尚未操作。');
      await require('../tools/capture-result').captureResult(window.webContents,'button-before',{x:0,y:0,width:600,height:260});
      await window.webContents.executeJavaScript("document.querySelector('#inspect-button').click()");
      await window.webContents.executeJavaScript('new Promise(resolve=>setTimeout(resolve,100))');
      assert.equal(await window.webContents.executeJavaScript("document.querySelector('#status').textContent"), '主程序已收到操作。');
      await require('../tools/capture-result').captureResult(window.webContents,'button-after',{x:0,y:0,width:600,height:260});
      assert.equal(await window.webContents.executeJavaScript("window.browser.command('unknown').then(()=>false,()=>true)"), true);
      console.log('CHAPTER 03 PASS: button, preload, trusted IPC, unknown command rejected, no renderer require');
      window.close();
    } catch (error) { console.error('CHAPTER 03 FAIL:', error.message); app.exit(1); }
  });
  window.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
if (smoke) setTimeout(() => { console.error('CHAPTER 03 FAIL: timeout'); app.exit(1); }, 10000).unref();
