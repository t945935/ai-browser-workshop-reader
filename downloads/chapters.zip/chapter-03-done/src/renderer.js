const status = document.querySelector('#status');
async function inspect() {
  try {
    const state = await window.browser.command('ping');
    status.textContent = state.message;
  } catch {
    status.textContent = '操作失敗，請核對主程序與 preload。';
  }
}
document.querySelector('#inspect-button').addEventListener('click', inspect);
