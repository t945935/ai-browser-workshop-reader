const { test } = require('node:test');
const assert = require('node:assert/strict');
const { normalizeUrl } = require('../src/url');
test('空白不導覽；省略協定補 HTTPS', () => {
  assert.equal(normalizeUrl('  '), null);
  assert.equal(normalizeUrl(' example.com '), 'https://example.com/');
  assert.equal(normalizeUrl('localhost:8080'), 'https://localhost:8080/');
  assert.equal(normalizeUrl('http://localhost:8080/a'), 'http://localhost:8080/a');
});
test('拒絕危險協定、憑證與錯誤輸入', () => {
  for (const input of ['javascript:alert(1)', 'file:///C:/a', 'data:text/html,hi', 'https://user:pass@example.com', 'bad url', 'https://', null]) {
    assert.throws(() => normalizeUrl(input));
  }
});
