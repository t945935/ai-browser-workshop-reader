// 網址處理保持獨立，方便測試輸入邊界。
function normalizeUrl(input) {
  if (typeof input !== 'string') throw new Error('網址必須是文字。');
  const value = input.trim();
  if (!value) return null;
  if (/\s/.test(value)) throw new Error('網址不能包含空白。');
  const hasScheme = /^[a-z][a-z\d+.-]*:/i.test(value);
  const isHostPort = /^(localhost|[\w.-]+):\d+(\/|$)/i.test(value);
  let url;
  try { url = new URL(hasScheme && !isHostPort ? value : `https://${value}`); }
  catch { throw new Error('請輸入有效網址。'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('僅支援 HTTP 與 HTTPS 網址。');
  if (url.username || url.password) throw new Error('請勿在網址中包含帳號或密碼。');
  return url.href;
}
module.exports = { normalizeUrl };
