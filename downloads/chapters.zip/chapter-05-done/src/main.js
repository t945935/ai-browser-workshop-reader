const { app, BrowserWindow, WebContentsView, ipcMain, session } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { normalizeUrl } = require('./url');

const UI_HEIGHT = 112;
const smoke = process.argv.includes('--smoke-test');
if (smoke) app.setPath('userData', require('node:fs').mkdtempSync(path.join(require('node:os').tmpdir(),'chapter05-result-')));
const uiUrl = pathToFileURL(path.join(__dirname, 'index.html')).href;
let window;
let page;
let message = '輸入網址開始瀏覽。';

function state() {
  const contents = page.webContents;
  return {
    url: contents.getURL(), title: contents.getTitle(),
    loading: contents.isLoading(), message,
    canGoBack: contents.navigationHistory.canGoBack(),
    canGoForward: contents.navigationHistory.canGoForward()
  };
}
function publish() {
  if (window && !window.isDestroyed() && page && !page.webContents.isDestroyed()) {
    window.webContents.send('browser:state', state());
  }
}
function resize() {
  const [width, height] = window.getContentSize();
  page.setBounds({ x: 0, y: UI_HEIGHT, width, height: Math.max(0, height - UI_HEIGHT) });
}
function navigate(input) {
  const target = normalizeUrl(input);
  if (!target) return;
  message = '';
  page.webContents.loadURL(target).catch(error => {
    if (error.code !== 'ERR_ABORTED') {
      message = `無法載入網頁：${error.code || '請檢查網路與網址'}`;
      publish();
    }
  });
}
function trusted(event) {
  return window && event.sender === window.webContents &&
    event.senderFrame === window.webContents.mainFrame && event.senderFrame.url === uiUrl;
}
ipcMain.handle('browser:command', (event, command, input) => {
  if (!trusted(event)) throw new Error('不允許的操作來源。');
  try {
    const history = page.webContents.navigationHistory;
    switch (command) {
      case 'state': break;
      case 'navigate': navigate(input); break;
      case 'back': if (history.canGoBack()) history.goBack(); break;
      case 'forward': if (history.canGoForward()) history.goForward(); break;
      case 'reload': if (page.webContents.getURL()) page.webContents.reload(); break;
      default: throw new Error('不支援的操作。');
    }
  } catch (error) { message = error.message; }
  publish();
  return state();
});

function createWindow() {
  window = new BrowserWindow({
    width: 1200, height: 800, minWidth: 640, minHeight: 360,
    title: 'My AI Browser', backgroundColor: '#f3f6fa',
    show: !smoke,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  window.setMenuBarVisibility(false);
  window.webContents.on('will-navigate', event => event.preventDefault());
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  page = new WebContentsView({ webPreferences: {
    contextIsolation: true, nodeIntegration: false, sandbox: true, partition: 'browser-prototype'
  } });
  window.contentView.addChildView(page);
  resize();
  window.on('resize', resize);
  const contents = page.webContents;
  contents.setWindowOpenHandler(() => ({ action: 'deny' }));
  for (const name of ['will-navigate', 'will-redirect']) {
    contents.on(name, (event, url) => {
      try { normalizeUrl(url); }
      catch (error) { event.preventDefault(); message = error.message; publish(); }
    });
  }
  contents.on('did-start-loading', () => { message = ''; publish(); });
  for (const name of ['did-stop-loading', 'did-navigate', 'did-navigate-in-page', 'page-title-updated']) {
    contents.on(name, publish);
  }
  contents.on('did-fail-load', (_event, code, description, _url, isMainFrame) => {
    if (isMainFrame && code !== -3) { message = `無法載入網頁：${description}`; publish(); }
  });
  contents.on('render-process-gone', () => { message = '網頁程序已停止，請重新整理。'; publish(); });
  window.on('closed', () => { if (!contents.isDestroyed()) contents.close(); window = null; page = null; });
  window.loadFile(path.join(__dirname, 'index.html'));
  if (smoke) {
    const timer = setTimeout(() => { console.error('SMOKE FAIL: timeout'); app.exit(1); }, 15000);
    window.webContents.once('did-finish-load', async () => {
      const server = require('node:http').createServer((_request, response) => {
        response.end('<!doctype html><title>Smoke page</title><p>Local test page</p>');
      });
      try {
        const ready = await window.webContents.executeJavaScript("Boolean(window.browser && document.querySelector('#address'))");
        if (!ready) throw new Error('工具列或 preload 未載入');
        await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
        await contents.loadURL(`http://127.0.0.1:${server.address().port}`);
        if (contents.getTitle() !== 'Smoke page') throw new Error('測試頁未載入');
        const assert = require('node:assert/strict');
        const base = `http://127.0.0.1:${server.address().port}`;
        async function loadFromUi(script) {
          const loaded = new Promise(resolve => contents.once('did-finish-load', resolve));
          await window.webContents.executeJavaScript(script);
          await loaded;
        }
        await loadFromUi(`document.querySelector('#address').value=${JSON.stringify(base + '/second')};document.querySelector('#navigation').requestSubmit()`);
        assert.equal(contents.getURL(), base + '/second');
        assert.equal(state().canGoBack, true);
        await require('../tools/capture-result').captureResult(window.webContents,'navigation-second',{x:0,y:0,width:1200,height:112});
        await loadFromUi("document.querySelector('#back').click()");
        assert.equal(contents.getURL(), base + '/');
        assert.equal(state().canGoForward, true);
        await require('../tools/capture-result').captureResult(window.webContents,'navigation-back',{x:0,y:0,width:1200,height:112});
        await loadFromUi("document.querySelector('#forward').click()");
        assert.equal(contents.getURL(), base + '/second');
        await loadFromUi("document.querySelector('#reload').click()");
        assert.equal(contents.getURL(), base + '/second');
        await window.webContents.executeJavaScript("document.querySelector('#address').value='   ';document.querySelector('#navigation').requestSubmit();new Promise(resolve=>setTimeout(resolve,100))");
        assert.equal(contents.getURL(), base + '/second');
        const invalid = await window.webContents.executeJavaScript("window.browser.command('navigate','javascript:alert(1)')");
        assert.match(invalid.message, /HTTP|HTTPS|協定/);
        assert.equal(contents.getURL(), base + '/second');
        assert.equal(await contents.executeJavaScript('typeof window.browser'), 'undefined');
        await require('../tools/capture-result').captureResult(window.webContents,'navigation-invalid',{x:0,y:0,width:1200,height:112});
        assert.equal(await window.webContents.executeJavaScript("document.querySelector('#back').disabled"), !state().canGoBack);
        console.log('CHAPTER 05 PASS: submit, history back/forward, reload, blank no-op, rejected scheme, isolated page');
        clearTimeout(timer);
        server.close();
        window.close();
      } catch (error) {
        console.error('SMOKE FAIL:', error.message);
        server.close();
        app.exit(1);
      }
    });
  }
}
app.whenReady().then(() => {
  const browserSession = session.fromPartition('browser-prototype');
  browserSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  browserSession.setPermissionCheckHandler(() => false);
  browserSession.on('will-download', event => event.preventDefault());
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
