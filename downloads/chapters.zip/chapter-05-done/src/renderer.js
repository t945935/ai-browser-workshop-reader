const address = document.querySelector('#address');
const status = document.querySelector('#status');
function render(state) {
  if (document.activeElement !== address) address.value = state.url;
  document.querySelector('#back').disabled = !state.canGoBack;
  document.querySelector('#forward').disabled = !state.canGoForward;
  document.querySelector('#reload').disabled = !state.url;
  status.textContent = state.message || (state.loading ? '正在載入…' : state.title || '就緒');
}
async function command(action, input) {
  try { render(await window.browser.command(action, input)); }
  catch { status.textContent = '操作失敗，請重新啟動程式。'; }
}
window.browser.onState(render);
document.querySelector('#navigation').addEventListener('submit', event => {
  event.preventDefault();
  address.blur();
  command('navigate', address.value);
});
for (const action of ['back', 'forward', 'reload']) {
  document.querySelector(`#${action}`).addEventListener('click', () => command(action));
}
command('state');
