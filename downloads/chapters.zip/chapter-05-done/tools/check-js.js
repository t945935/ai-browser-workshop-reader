const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const files = [];
for (const directory of ['src', 'tools', 'practice-site']) {
  if (!fs.existsSync(directory)) continue;
  for (const name of fs.readdirSync(directory)) if (name.endsWith('.js')) files.push(path.join(directory, name));
}
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) { process.stderr.write(result.stderr || `Syntax check failed: ${file}\n`); process.exit(1); }
}
console.log(`PASS: ${files.length} JavaScript files parsed.`);
