# 第 5 章完成版

從固定網頁改成網址輸入、前往、上一頁、下一頁與重新整理。輸入先驗證，只允許 HTTP／HTTPS；空白不導覽，缺協定補 HTTPS。

在本目錄執行 npm.cmd ci、npm.cmd test、npm.cmd start。npm.cmd run smoke 透過實際 renderer 表單與按鈕驗證導覽和歷史，並核對空白不導覽、危險協定被拒絕與頁面隔離。測試使用本機 HTTP 來源，不代表已驗證外部網路連線。
