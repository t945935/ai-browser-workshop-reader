const { test } = require('node:test');
const assert = require('node:assert/strict');
const { exportBooks, importBooks } = require('../src/book-format');
const books = [{ title: '中文,書名"', author: '作者', description: '第一行\r\n第二行,"內容"', keywords: ['含,逗號', '引號"', 'AI'] }];
test('JSON 與 CSV 保留中文、換行、逗號、引號及關鍵字', () => {
  for (const format of ['json', 'csv']) {
    assert.deepEqual(importBooks(exportBooks(books, format), format), books);
    assert.deepEqual(importBooks(exportBooks([], format), format), []);
  }
});
test('拒絕未知版本、錯誤欄位、未閉合引號與無效書籍', () => {
  for (const text of ['{}', '{bad', '{"formatVersion":2,"books":[]}', '{"formatVersion":1,"books":[{"title":"","keywords":[]}]}']) assert.throws(() => importBooks(text, 'json'));
  for (const text of ['title\na', '"formatVersion","title","author","description","keywords"\n1,"unfinished', 'formatVersion,title,author,description,keywords\n2,title,author,text,[]', 'formatVersion,title,author,description,keywords\n1,"a"oops,b,c,[]']) assert.throws(() => importBooks(text, 'csv'));
});
test('隨書 JSON 與 CSV 表達相同資料', () => {
  const fs = require('node:fs');
  assert.deepEqual(importBooks(fs.readFileSync('examples/books.json', 'utf8'), 'json'), importBooks(fs.readFileSync('examples/books.csv', 'utf8'), 'csv'));
});
