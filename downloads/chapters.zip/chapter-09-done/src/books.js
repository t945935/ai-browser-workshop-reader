const { DatabaseSync, backup } = require('node:sqlite');
const { randomUUID } = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
function sameFile(left, right) {
  const canonical = value => {
    const absolute = path.resolve(value);
    const resolved = fs.existsSync(absolute) ? fs.realpathSync(absolute) : absolute;
    return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
  };
  return canonical(left) === canonical(right);
}
function validateBook(value) {
  if (!value || typeof value.title !== 'string' || !value.title.trim()) throw new Error('書名不可空白。');
  for (const key of ['title', 'author', 'description']) {
    if (value[key] !== undefined && (typeof value[key] !== 'string' || value[key].length > 20000)) throw new Error(`${key} 格式不正確。`);
  }
  if (!Array.isArray(value.keywords) || value.keywords.length > 100 || value.keywords.some(word => typeof word !== 'string' || word.length > 200)) throw new Error('關鍵字格式不正確。');
  return { title: value.title.trim(), author: value.author || '', description: value.description || '', keywords: value.keywords.map(word => word.trim()).filter(Boolean) };
}
function decode(row) { return row && { ...row, keywords: JSON.parse(row.keywords) }; }
class BookStore {
  constructor(directory) {
    fs.mkdirSync(directory, { recursive: true }); this.file = path.join(directory, 'books.sqlite');
    this.db = new DatabaseSync(this.file);
    const version = this.db.prepare('PRAGMA user_version').get().user_version;
    if (version !== 0 && version !== 1) { this.db.close(); throw new Error('資料庫版本不相容，請保留檔案並使用對應版本程式。'); }
    this.db.exec(`CREATE TABLE IF NOT EXISTS books (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL, description TEXT NOT NULL,
      keywords TEXT NOT NULL, createdAt TEXT NOT NULL, updatedAt TEXT NOT NULL
    ) STRICT; PRAGMA user_version = 1;`);
  }
  list(query = '') {
    if (typeof query !== 'string' || query.length > 200) throw new Error('搜尋文字過長。');
    return this.db.prepare('SELECT * FROM books WHERE instr(title, ?) > 0 OR instr(author, ?) > 0 OR instr(description, ?) > 0 ORDER BY updatedAt DESC, id').all(query, query, query).map(decode);
  }
  get(id) { return decode(this.db.prepare('SELECT * FROM books WHERE id = ?').get(id)); }
  save(value) {
    const book = validateBook(value); const now = new Date().toISOString();
    const id = value.id || randomUUID();
    if (typeof id !== 'string' || id.length > 100) throw new Error('識別碼不正確。');
    if (value.id) {
      if (!this.get(id)) throw new Error('書籍已不存在，請重新選擇。');
      this.db.prepare('UPDATE books SET title=?, author=?, description=?, keywords=?, updatedAt=? WHERE id=?').run(book.title, book.author, book.description, JSON.stringify(book.keywords), now, id);
    } else this.db.prepare('INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, book.title, book.author, book.description, JSON.stringify(book.keywords), now, now);
    return this.get(id);
  }
  delete(id) {
    if (typeof id !== 'string') throw new Error('識別碼不正確。');
    this.db.prepare('DELETE FROM books WHERE id=?').run(id);
  }
  import(books) {
    if (!Array.isArray(books) || books.length > 10000) throw new Error('匯入資料最多一萬筆。');
    const checked = books.map(validateBook);
    this.db.exec('BEGIN IMMEDIATE');
    try { for (const book of checked) this.save(book); this.db.exec('COMMIT'); }
    catch (error) { this.db.exec('ROLLBACK'); throw error; }
    return checked.length;
  }
  async backup(destination) {
    if (sameFile(destination, this.file)) throw new Error('備份不可覆蓋目前資料庫。');
    await backup(this.db, destination);
  }
  async restore(source) {
    if (sameFile(source, this.file)) throw new Error('請選擇另一個備份檔。');
    const candidate = new DatabaseSync(source, { readOnly: true }); let records;
    try {
      if (candidate.prepare('PRAGMA quick_check').get().quick_check !== 'ok') throw new Error('資料庫檢查失敗。');
      if (candidate.prepare('PRAGMA user_version').get().user_version !== 1) throw new Error('備份版本不相容。');
      records = candidate.prepare('SELECT * FROM books').all().map(decode);
      records.forEach(validateBook);
    } finally { candidate.close(); }
    const recovery = `${this.file}.before-restore-${Date.now()}`;
    await this.backup(recovery);
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.exec('DELETE FROM books');
      const insert = this.db.prepare('INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?)');
      for (const row of records) insert.run(row.id, row.title, row.author, row.description, JSON.stringify(row.keywords), row.createdAt, row.updatedAt);
      this.db.exec('COMMIT');
    } catch (error) { this.db.exec('ROLLBACK'); throw error; }
    return recovery;
  }
  close() { this.db.close(); }
}
module.exports = { BookStore, validateBook, sameFile };
