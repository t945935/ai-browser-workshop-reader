const { validateBook } = require('./books');
const HEADERS = ['formatVersion', 'title', 'author', 'description', 'keywords'];
// 以 JSON 陣列保存關鍵字，避免關鍵字本身的逗號產生歧義。
function exportBooks(books, format) {
  const checked = books.map(validateBook);
  if (format === 'json') return JSON.stringify({ formatVersion: 1, books: checked }, null, 2);
  if (format !== 'csv') throw new Error('不支援的匯出格式。');
  const quote = value => `"${String(value).replaceAll('"', '""')}"`;
  return '\uFEFF' + [HEADERS, ...checked.map(book => [1, book.title, book.author, book.description, JSON.stringify(book.keywords)])].map(row => row.map(quote).join(',')).join('\r\n');
}
function parseCsv(text) {
  const rows = []; let row = [], field = '', quoted = false, endedQuote = false;
  text = text.replace(/^\uFEFF/, '');
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (quoted) {
      if (character === '"') {
        if (text[index + 1] === '"') { field += '"'; index++; }
        else { quoted = false; endedQuote = true; }
      } else field += character;
    } else if (character === ',' || character === '\n' || character === '\r') {
      row.push(field); field = ''; endedQuote = false;
      if (character !== ',') { rows.push(row); row = []; if (character === '\r' && text[index + 1] === '\n') index++; }
    } else if (character === '"' && field === '' && !endedQuote) quoted = true;
    else {
      if (endedQuote || character === '"') throw new Error('CSV 引號格式不正確。');
      field += character;
    }
  }
  if (quoted) throw new Error('CSV 引號尚未結束。');
  if (field || row.length || endedQuote) { row.push(field); rows.push(row); }
  return rows;
}
function importBooks(text, format) {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > 10 * 1024 * 1024) throw new Error('匯入檔案最多 10 MB。');
  let books;
  if (format === 'json') {
    let data;
    try { data = JSON.parse(text.replace(/^\uFEFF/, '')); } catch { throw new Error('JSON 檔案格式不正確。'); }
    if (!data || data.formatVersion !== 1 || !Array.isArray(data.books)) throw new Error('JSON 格式版本或書籍清單不正確。');
    books = data.books;
  } else if (format === 'csv') {
    const [header, ...rows] = parseCsv(text);
    if (!header || header.join('\u0000') !== HEADERS.join('\u0000')) throw new Error('CSV 欄位必須依序為 formatVersion,title,author,description,keywords。');
    books = rows.map((row, index) => {
      if (row.length !== HEADERS.length || row[0] !== '1') throw new Error(`CSV 第 ${index + 2} 列的欄位或版本不正確。`);
      let keywords;
      try { keywords = JSON.parse(row[4]); } catch { throw new Error(`CSV 第 ${index + 2} 列關鍵字必須是 JSON 陣列。`); }
      return { title: row[1], author: row[2], description: row[3], keywords };
    });
  } else throw new Error('只接受 JSON 或 CSV 檔案。');
  if (books.length > 10000) throw new Error('匯入資料最多一萬筆。');
  return books.map(validateBook);
}
module.exports = { exportBooks, importBooks, parseCsv };
