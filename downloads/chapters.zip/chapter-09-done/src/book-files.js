const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { exportBooks, importBooks } = require('./book-format');
const { sameFile } = require('./books');
class BookFiles {
  constructor(store, dialog, window) { this.store = store; this.dialog = dialog; this.window = window; this.pending = null; this.busy = false; }
  async run(action, input) {
    if (this.busy) throw new Error('檔案操作進行中，請稍候。');
    this.busy = true;
    try {
      if (action === 'import-cancel') { this.pending = null; return { canceled: true }; }
      if (action === 'import-confirm') {
        const pending = this.pending;
        if (!pending || input !== pending.token || Date.now() - pending.created > 10 * 60 * 1000) throw new Error('匯入預覽已失效，請重新選擇檔案。');
        this.pending = null;
        return { imported: this.store.import(pending.books) };
      }
      if (action === 'import-preview') {
        this.pending = null;
        const result = await this.dialog.showOpenDialog(this.window, { title: '選擇書籍資料', properties: ['openFile'], filters: [{ name: '書籍資料', extensions: ['json', 'csv'] }] });
        if (result.canceled) return { canceled: true };
        const file = result.filePaths[0];
        if (fs.statSync(file).size > 10 * 1024 * 1024) throw new Error('匯入檔案最多 10 MB。');
        const format = path.extname(file).slice(1).toLowerCase();
        const books = importBooks(fs.readFileSync(file, 'utf8'), format);
        const token = randomUUID();
        this.pending = { token, books, created: Date.now() };
        return { preview: { token, filename: path.basename(file), count: books.length, titles: books.slice(0, 10).map(book => book.title) } };
      }
      if (action === 'export') {
        if (!['json', 'csv'].includes(input)) throw new Error('不支援的匯出格式。');
        const result = await this.dialog.showSaveDialog(this.window, { title: '匯出全部書籍', defaultPath: `books.${input}`, filters: [{ name: input.toUpperCase(), extensions: [input] }] });
        if (result.canceled) return { canceled: true };
        if (sameFile(result.filePath, this.store.file)) throw new Error('不可覆寫目前資料庫。');
        const records = this.store.list();
        fs.writeFileSync(result.filePath, exportBooks(records, input), 'utf8');
        return { exported: records.length };
      }
      if (action === 'backup') {
        const result = await this.dialog.showSaveDialog(this.window, { title: '備份書籍資料庫', defaultPath: 'books-backup.sqlite', filters: [{ name: 'SQLite 備份', extensions: ['sqlite'] }] });
        if (result.canceled) return { canceled: true };
        await this.store.backup(result.filePath); return { backedUp: true };
      }
      if (action === 'restore') {
        const result = await this.dialog.showOpenDialog(this.window, { title: '選擇資料庫備份', properties: ['openFile'], filters: [{ name: 'SQLite 備份', extensions: ['sqlite'] }] });
        if (result.canceled) return { canceled: true };
        const confirmation = await this.dialog.showMessageBox(this.window, { type: 'warning', buttons: ['取消', '還原'], defaultId: 0, cancelId: 0, message: '還原會替換全部書籍資料。程式會先建立還原前備份，確定繼續？' });
        if (confirmation.response !== 1) return { canceled: true };
        this.pending = null;
        return { recovery: await this.store.restore(result.filePaths[0]) };
      }
      throw new Error('不支援的檔案操作。');
    } finally { this.busy = false; }
  }
}
module.exports = { BookFiles };
