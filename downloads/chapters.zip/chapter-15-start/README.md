# 第 15 章 start

本版包含：第 14 章立即檢查與填入。

複製到自己的練習目錄，以 Node.js 24.21.0 執行 `npm.cmd ci`、`npm.cmd start`。Electron 鎖定 44.5.0。驗收命令：`npm.cmd test`、`npm.cmd run check`、`npm.cmd run smoke`。

完成版預覽延遲模式會等待欄位；缺少模式五秒後停止，重新回一般模式可再次操作。operation-log.jsonl 在使用者資料目錄，僅含 at、action、status。等待時不允許書籍、檔案還原或文案保存干擾。

smoke 使用實際本機 DOM 與暫存資料，短暫顯示視窗，約需十秒，不需要真實 AI。正常啟動可能與其他章節共用資料，切換前先備份。
