const fs = require('node:fs');
const path = require('node:path');
const DEFAULT_MODEL = 'gpt-4.1-mini-2025-04-14';
function modelName(value) {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9_.-]{1,100}$/.test(value)) throw new Error('模型名稱格式不正確。');
  return value;
}
class AiConfig {
  constructor(directory, safeStorage, environment = process.env) {
    this.file = path.join(directory, 'ai-settings.json'); this.safeStorage = safeStorage; this.environment = environment;
    this.model = DEFAULT_MODEL; this.key = ''; this.ciphertext = ''; this.error = ''; this.sessionOnly = false;
    fs.mkdirSync(directory, { recursive: true });
    try {
      const value = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (value.version !== 1 || typeof value.ciphertext !== 'string') throw new Error('invalid');
      this.model = modelName(value.model); this.ciphertext = value.ciphertext;
      if (this.ciphertext) {
        if (!safeStorage.isEncryptionAvailable()) throw new Error('unavailable');
        this.key = safeStorage.decryptString(Buffer.from(this.ciphertext, 'base64'));
      }
    } catch (error) { if (error.code !== 'ENOENT') this.error = 'AI 設定無法讀取，請重新設定模型與金鑰；原檔會保留備份。'; }
  }
  getKey() { return this.key || this.environment.OPENAI_API_KEY || ''; }
  status() { return { model: this.model, hasKey: Boolean(this.getKey()), sessionOnly: this.sessionOnly, keySource: this.key ? 'local' : this.environment.OPENAI_API_KEY ? 'environment' : 'none', error: this.error }; }
  save(value) {
    const model = modelName(value?.model);
    if (typeof value.key !== 'string' || (value.key && !/^[^\s]{20,512}$/.test(value.key))) throw new Error('金鑰格式不正確，請確認沒有空白。');
    const key = value.key || this.key;
    const available = this.safeStorage.isEncryptionAvailable();
    const ciphertext = key && available ? this.safeStorage.encryptString(key).toString('base64') : '';
    const data = { version: 1, model, ciphertext };
    if (this.error && fs.existsSync(this.file)) fs.copyFileSync(this.file, `${this.file}.backup-${Date.now()}`);
    fs.writeFileSync(`${this.file}.tmp`, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(`${this.file}.tmp`, this.file);
    this.model = model; this.key = key; this.ciphertext = ciphertext; this.sessionOnly = Boolean(key && !available); this.error = '';
    return this.status();
  }
  clear() {
    fs.writeFileSync(`${this.file}.tmp`, JSON.stringify({ version: 1, model: this.model, ciphertext: '' }, null, 2), 'utf8');
    fs.renameSync(`${this.file}.tmp`, this.file);
    this.key = ''; this.ciphertext = ''; this.sessionOnly = false; this.error = '';
    return this.status();
  }
}
module.exports = { AiConfig, DEFAULT_MODEL, modelName };
