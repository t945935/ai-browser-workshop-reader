const assert = require('node:assert/strict');
const { captureResult } = require('../tools/capture-result');
async function run({app,window,aiClient}) {
  const timer=setTimeout(()=>app.exit(1),15000);
  const js=script=>window.webContents.executeJavaScript(script);
  async function waitFor(text) {
    await js(`new Promise((resolve,reject)=>{const timer=setTimeout(()=>{clearInterval(poll);reject(new Error('AI 介面等待逾時'));},3000);const poll=setInterval(()=>{if(document.querySelector('#ai-request-status').textContent.includes(${JSON.stringify(text)})){clearTimeout(timer);clearInterval(poll);resolve();}},20);})`);
  }
  async function capture(name) {
    await js("document.querySelector('#ai-panel').scrollIntoView();document.querySelector('#ai-key').value=''");
    const box=await js("(()=>{const b=document.querySelector('#ai-panel').getBoundingClientRect();return {y:Math.floor(b.top),height:Math.ceil(b.height)};})()");
    assert.ok(box.y>=184 && box.y+box.height<=window.getContentSize()[1]);
    await captureResult(window.webContents,name,{x:0,y:box.y,width:300,height:box.height});
  }
  try {
    window.setContentSize(1200,1000);
    await js("document.querySelector('#ai-send').click()"); await waitFor('請先設定');
    assert.equal(aiClient.busy,false); await capture('ai-no-key');
    await js("document.querySelector('#ai-model').value='offline-test-model';document.querySelector('#ai-key').value='offline-fixture-not-a-real-key';document.querySelector('#ai-save').click()");
    await waitFor('設定已保存');
    assert.equal(await js("document.querySelector('#ai-key').value"),'');
    const status=await js("window.browser.command('ai-status')");
    assert.equal(status.hasKey,true); assert.equal(JSON.stringify(status).includes('offline-fixture'),false);
    let calls=0;
    aiClient.fetcher=async(url,options)=>{
      calls++; assert.equal(url,'https://api.openai.com/v1/responses');
      const body=JSON.parse(options.body); assert.equal(body.text,undefined); assert.equal(body.tools,undefined);
      return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'離線測試回應：練習整理書籍與保存設定。'}]}]})};
    };
    await js("document.querySelector('#ai-send').click()"); await waitFor('請求完成');
    assert.equal(calls,1); assert.equal(aiClient.busy,false); await capture('ai-offline-success');
    aiClient.fetcher=async()=>({ok:false,status:401});
    await js("document.querySelector('#ai-send').click()"); await waitFor('金鑰無效');
    assert.equal(aiClient.busy,false); await capture('ai-invalid-key');
    aiClient.fetcher=async(_url,{signal})=>new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted')),{once:true}));
    await js("document.querySelector('#ai-send').click()");
    assert.equal(await js("document.querySelector('#ai-send').disabled"),true);
    const duplicate=await js("window.browser.command('ai-request','重複')"); assert.match(duplicate.error,/進行中/);
    await js("document.querySelector('#ai-cancel').click()"); await waitFor('已取消');
    assert.equal(aiClient.busy,false); assert.equal(await js("document.querySelector('#ai-send').disabled"),false);
    console.log('CHAPTER 10 PASS: local config, text request, missing key, offline success, HTTP 401, busy lock, cancel; no live API');
  } finally { aiClient.cancel(); clearTimeout(timer); window.close(); }
}
module.exports={run};
