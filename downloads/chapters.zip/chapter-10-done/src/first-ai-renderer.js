// 第 10 章只處理自寫文字請求，不擷取外部頁面，也不保存 AI 文案。
(() => {
  const find = id => document.querySelector(`#${id}`);
  const message = find('ai-request-status');
  let waiting = false;
  async function invoke(command,input) {
    const result = await window.browser.command(command,input);
    if (result.error) throw new Error(result.error);
    return result;
  }
  function busy(value) {
    waiting = value;
    for (const id of ['ai-send','ai-save','ai-clear','ai-model','ai-key','ai-input']) find(id).disabled = value;
    find('ai-cancel').disabled = !value;
  }
  function showConfig(value) {
    find('ai-model').value = value.model;
    find('ai-config-status').textContent = `${value.hasKey ? '已設定金鑰' : '尚未設定金鑰'}；來源：${value.keySource}${value.sessionOnly ? '；僅保留本次執行' : ''}${value.error ? '；'+value.error : ''}`;
  }
  find('ai-save').addEventListener('click',async()=>{
    if (waiting) return;
    try {
      showConfig(await invoke('ai-config',{model:find('ai-model').value,key:find('ai-key').value}));
      find('ai-key').value = ''; message.textContent = '設定已保存。';
    } catch(error) { message.textContent = error.message; }
  });
  find('ai-clear').addEventListener('click',async()=>{
    if (waiting) return;
    try { showConfig(await invoke('ai-clear-key')); find('ai-key').value=''; message.textContent='本機金鑰已清除；環境變數需在外部自行移除。'; }
    catch(error) { message.textContent=error.message; }
  });
  find('ai-send').addEventListener('click',async()=>{
    if (waiting) return;
    const input = find('ai-input').value;
    busy(true); message.textContent='等待 AI 回應…'; find('ai-output').textContent='';
    try { const result=await invoke('ai-request',input); find('ai-output').textContent=result.text; message.textContent='請求完成，請核對來源文字。'; }
    catch(error) { message.textContent=error.message; }
    finally { busy(false); }
  });
  find('ai-cancel').addEventListener('click',async()=>{
    try { await invoke('ai-cancel'); } catch(error) { message.textContent=error.message; }
  });
  invoke('ai-status').then(showConfig).catch(error=>{message.textContent=error.message;});
})();
