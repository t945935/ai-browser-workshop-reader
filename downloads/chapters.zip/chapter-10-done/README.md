# 第 10 章done

本版包含：自寫文字 AI 請求、金鑰、等待、取消與錯誤；尚無網頁擷取或書籍文案建議。

複製到自己的練習目錄，使用 Node.js 24.21.0，在該目錄執行 `npm.cmd ci`、`npm.cmd start`。Electron 鎖定 44.5.0。

`npm.cmd test` 與 `npm.cmd run smoke` 使用離線測試，不會證明真實 API 成功。完成版 `npm.cmd run first-ai` 使用本機 OPENAI_API_KEY，成功時會發出一次真實請求。正常視窗也可從 API 設定輸入本機金鑰。金鑰不交給聊天、Git 或截圖。

正常啟動可能與其他章節共用同名使用者資料，切換前先備份。smoke 使用暫存 userData，忽略真實環境金鑰，截圖中的回應標明離線測試。
