// 第 10 章：用自寫短文字完成一次摘要請求，不操作網頁或資料庫。
const { AiClient } = require('../src/ai-client');
const { DEFAULT_MODEL } = require('../src/ai-config');
async function main() {
  if (!process.env.OPENAI_API_KEY) {
    console.error('尚未設定本機 OPENAI_API_KEY；未發出請求。不要把金鑰貼到對話或提交到 Git。');
    process.exitCode = 2;
    return;
  }
  const client = new AiClient({
    model: process.env.OPENAI_MODEL || DEFAULT_MODEL,
    getKey: () => process.env.OPENAI_API_KEY
  });
  try {
    const summary = await client.request('這是一段自寫練習文字：我正在建立自己的工作瀏覽器。工具可以整理書籍資料，提出 AI 文案建議，並在確認後保存。');
    console.log('請求完成。以下是摘要，請人工核對是否符合來源：');
    console.log(summary);
  } catch (error) {
    console.error('請求失敗：', error.message);
    process.exitCode = 1;
  }
}
main().catch(() => { console.error('範例無法啟動。'); process.exitCode = 1; });
