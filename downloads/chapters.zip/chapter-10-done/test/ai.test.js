const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {AiConfig}=require('../src/ai-config');
const {AiClient}=require('../src/ai-client');
const config={model:'offline-model',getKey:()=> 'offline-not-a-real-key'};
const completed=text=>({ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text}]}]})});
test('金鑰不出現在公開狀態；無加密能力時重開不保留金鑰',()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'chapter10-key-'));
  // 僅測試分支；此替代物不是安全加密演算法。
  const storage={isEncryptionAvailable:()=>true,encryptString:key=>Buffer.from(key.split('').reverse().join('')),decryptString:bytes=>bytes.toString().split('').reverse().join('')};
  const value=new AiConfig(directory,storage,{});
  value.save({model:config.model,key:config.getKey()});
  assert.equal(JSON.stringify(value.status()).includes(config.getKey()),false);
  assert.equal(fs.readFileSync(value.file,'utf8').includes(config.getKey()),false);
  assert.equal(new AiConfig(directory,storage,{}).getKey(),config.getKey());
  storage.isEncryptionAvailable=()=>false;
  value.save({model:config.model,key:config.getKey()}); assert.equal(value.status().sessionOnly,true);
  assert.equal(new AiConfig(directory,storage,{}).getKey(),'');
  value.clear(); assert.equal(value.getKey(),'');
});
test('第一次文字請求固定端點，不含工具與結構化文案',async()=>{
  let sent;
  const client=new AiClient(config,async(url,options)=>{sent={url,body:JSON.parse(options.body),redirect:options.redirect};return completed('離線摘要');});
  assert.equal(await client.request('自寫文字'),'離線摘要');
  assert.equal(sent.url,'https://api.openai.com/v1/responses');
  assert.equal(sent.redirect,'error'); assert.equal(sent.body.model,config.model);
  assert.equal(sent.body.store,false); assert.equal(sent.body.tools,undefined); assert.equal(sent.body.text,undefined);
  assert.equal(sent.body.input[0].content[0].text,'自寫文字'); assert.equal(client.busy,false);
});
test('無金鑰不送出，401、429與未完成回應恢復請求鎖',async()=>{
  let calls=0; const client=new AiClient({getKey:()=>''},async()=>{calls++;});
  await assert.rejects(client.request('資料'),/請先設定/); assert.equal(calls,0);
  client.config=config;
  for(const [status,pattern] of [[401,/金鑰無效/],[429,/用量或速率/]]) {
    client.fetcher=async()=>({ok:false,status}); await assert.rejects(client.request('資料'),pattern); assert.equal(client.busy,false);
  }
  client.fetcher=async()=>({ok:true,json:async()=>({status:'incomplete',output:[]})});
  await assert.rejects(client.request('資料'),/未完成/); assert.equal(client.busy,false);
});
test('等待中拒絕重複請求，取消與逾時後可再次送出',async()=>{
  const wait=async(_url,{signal})=>new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('abort')),{once:true}));
  const client=new AiClient(config,wait,500);
  const pending=client.request('資料'); await assert.rejects(client.request('第二次'),/進行中/);
  client.cancel(); await assert.rejects(pending,/已取消/); assert.equal(client.busy,false);
  client.timeoutMs=10; await assert.rejects(client.request('資料'),/逾時/); assert.equal(client.busy,false);
  client.fetcher=async()=>completed('可再次操作'); assert.equal(await client.request('資料'),'可再次操作');
});
