# 第 4 章起始版

沿用第 3 章的本機按鈕與 IPC。執行 npm.cmd ci、npm.cmd start，依第 4 章加入固定網頁及縮放。完成版在相鄰 chapter-04-done。
