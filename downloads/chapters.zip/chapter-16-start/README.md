# 第 16 章 start

應用程式沿用第 15 章完成版。除錯練習獨立放在 exercises/csv-debug，不改動正式匯入功能。

執行 npm.cmd run test:debug：start 預期兩項失敗，done 預期兩項通過。兩版使用相同測試；修正只替換 parser.js，重用 src/book-format.js 的引號狀態解析器。

既有回歸：npm.cmd test、npm.cmd run check。啟動介面前執行 npm.cmd ci；npm.cmd run smoke 使用第 15 章實際 DOM 驗收，不需要真實 API。
