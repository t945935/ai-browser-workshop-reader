const {test}=require('node:test');
const assert=require('node:assert/strict');
const {parseCsv}=require('./parser');
test('CSV keeps a comma inside a quoted title',()=>{
  assert.deepEqual(parseCsv('title,author\r\n"AI, browser",Happy'),[['title','author'],['AI, browser','Happy']]);
});
test('CSV keeps escaped quotes and a newline inside one field',()=>{
  assert.deepEqual(parseCsv('"He said ""Hello""","first\nsecond"'),[['He said "Hello"','first\nsecond']]);
});
