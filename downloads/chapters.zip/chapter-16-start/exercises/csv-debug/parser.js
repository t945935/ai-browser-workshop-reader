module.exports.parseCsv = text => text.replace(/^\uFEFF/, '').split(/\r?\n/).map(line => line.split(','));
